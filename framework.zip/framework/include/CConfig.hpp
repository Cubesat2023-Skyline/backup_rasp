#pragma once

/*
████████╗██╗  ██╗███████╗ ██████╗ ███████╗      ██████╗  █████╗
╚══██╔══╝██║  ██║██╔════╝██╔═══██╗██╔════╝      ╚════██╗██╔══██╗
   ██║   ███████║█████╗  ██║   ██║███████╗█████╗ █████╔╝███████║
   ██║   ██╔══██║██╔══╝  ██║   ██║╚════██║╚════╝██╔═══╝ ██╔══██║
   ██║   ██║  ██║███████╗╚██████╔╝███████║      ███████╗██║  ██║
   ╚═╝   ╚═╝  ╚═╝╚══════╝ ╚═════╝ ╚══════╝      ╚══════╝╚═╝  ╚═╝

 File: CConfig.cpp
 Author: Aroonsak Bootchai [AB]
===============================================================
Config parser as a Config struct.

 Developer: Aroonsak Bootchai
 Project: SchoolSAT
 Date: 2022-Jun-12
 Version: 010
============================================================
*/

#include <fstream>
#include <iostream>
#include <map>
#include <string>

#include "./CExecutor.hpp"

// PROMPT > write C++20 code that read the file (.cfg) and parse the config and store in pointer
struct Config {
  std::map<std::string, int32_t> data;
};

Config* parseConfigFile(const std::string& filename) {
  std::ifstream file(filename);
  if (!file.is_open()) {
    std::cerr << "Error: Failed to open configuration file.\n";
    return nullptr;
  }

  Config* config = new Config();
  std::string line;
  while (std::getline(file, line)) {
    // Skip empty lines and comments
    if (line.empty() || line[0] == '#') continue;

    // Find the position of the equal sign
    size_t equalPos = line.find('=');
    if (equalPos != std::string::npos) {
      // Split the line into key and value
      std::string key = line.substr(0, equalPos);
      key.erase(std::find_if(key.rbegin(), key.rend(), [](unsigned char ch) { return !std::isspace(ch); }).base(), key.end());
      std::string value = line.substr(equalPos + 1);
      value.erase(value.begin(), std::find_if(value.begin(), value.end(), [](unsigned char ch) { return !std::isspace(ch); }));
      // Store key-value pair in the configuration data
      config->data[key] = std::stoi(value);
    }
  }
  file.close();
  std::cout << fmt::format("[CFG] {} Config has been Loaded", config->data.size()).c_str() << std::endl << std::flush;
  return config;
}

Config* ParseConfig(ParseArguments* args) {
  if (args->list.contains("-c")) {
    return parseConfigFile(args->list["-c"]);
  };
  if (args->list.contains("--config")) {
    return parseConfigFile(args->list["--config"]);
  };
  return nullptr;
};
