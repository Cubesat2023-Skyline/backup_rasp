#pragma once

/*
████████╗██╗  ██╗███████╗ ██████╗ ███████╗      ██████╗  █████╗
╚══██╔══╝██║  ██║██╔════╝██╔═══██╗██╔════╝      ╚════██╗██╔══██╗
   ██║   ███████║█████╗  ██║   ██║███████╗█████╗ █████╔╝███████║
   ██║   ██╔══██║██╔══╝  ██║   ██║╚════██║╚════╝██╔═══╝ ██╔══██║
   ██║   ██║  ██║███████╗╚██████╔╝███████║      ███████╗██║  ██║
   ╚═╝   ╚═╝  ╚═╝╚══════╝ ╚═════╝ ╚══════╝      ╚══════╝╚═╝  ╚═╝

 File: CLog.cpp
 Author: Aroonsak Bootchai [AB]
===============================================================
CLog is a library of utility functions designed to facilitate
Log controls in the spacecraft

 Developer: Aroonsak Bootchai
 Project: SchoolSAT
 Date: 2022-Jun-12
 Version: 100
===============================================================
*/

#include <fmt/color.h>
#include <fmt/format.h>
#include <mqueue.h>

#include <cerrno>
#include <chrono>
#include <cstring>
#include <ctime>
#include <iomanip>
#include <iostream>
#include <string>

enum class LogLevel : uint8_t
{
  DEBUG,
  INFO,
  WARNING,
  ERROR
};

constexpr const size_t max_log_message_size = 236;

struct LogMessage {
  uint32_t timestamp;
  LogLevel level;
  int moduleId;
  char message[max_log_message_size];
};

class Logger {
 public:
  bool mq_service{false};

  std::string mq_log_name;

  void setLogLevel(LogLevel level) { logLevel = level; }
  void setLogLevel(int32_t level) { logLevel = static_cast<LogLevel>(level); }

  void setModuleID(int num) { module_id = num; }

  void setService() {
    mq_service = true;
    // Open the message queue
    mq_log = mq_open("/log", O_WRONLY | O_CREAT, 0666, nullptr);
    if (mq_log == -1) {
      std::cerr << "Failed to open message queue: " << strerror(errno) << std::endl << std::flush;
    }
  }

  void setLogMQName(std::string args) { mq_log_name = args; }

  void setManualMQService() {
    if (mq_service == false) {
      if (!mq_log_name.empty()) {
        mq_service = true;
        mq_log = mq_open(mq_log_name.c_str(), O_WRONLY | O_CREAT, 0666, nullptr);
        if (mq_log == -1) {
          std::cerr << "Failed to open message queue: " << strerror(errno) << std::endl << std::flush;
        }
      }
    }
  }

  void log(const std::string& message) { log(LogLevel::DEBUG, message); }

  void log(LogLevel level, const std::string& message) {
    time_t currentTime = time(nullptr);

    LogMessage msg = {.timestamp = static_cast<uint32_t>(currentTime), .level = level, .moduleId = module_id};
    memset(msg.message, 0, max_log_message_size * sizeof(char));
    strcpy(msg.message, message.c_str());

    if (mq_service) {
      if (mq_send(mq_log, (char*)&msg, sizeof(msg), 1) == -1) {
        std::cerr << "Failed to send message to the queue." << std::endl << std::flush;
      }
    }
    struct tm* timeInfo = localtime(&currentTime);
    char formattedTime[24];
    strftime(formattedTime, sizeof(formattedTime), "%d%b%Y %H:%M:%S", timeInfo);

    if (level >= logLevel) {
      if (level == LogLevel::ERROR) {
        std::cout << fmt::format("{} {:4} ", formattedTime, module_id) << fmt::format(fg(fmt::color::red), "{:5} {}", getLogLevelString(level), message) << std::endl << std::flush;
      } else {
        std::cerr << fmt::format("{} {:4} {:5} {}", formattedTime, module_id, getLogLevelString(level), message).c_str() << std::endl << std::flush;
      }
    }
  }

 private:
  mqd_t mq_log;
  int module_id;
  LogLevel logLevel = LogLevel::INFO;

  std::string getLogLevelString(LogLevel level) {
    switch (level) {
      case LogLevel::INFO:
        return "INFO";
      case LogLevel::WARNING:
        return "WARN";
      case LogLevel::ERROR:
        return "ERROR";
      case LogLevel::DEBUG:
      default:
        return "DEBUG";
    }
  }
};

std::string getLogLevelString(LogLevel level) {
  switch (level) {
    case LogLevel::INFO:
      return "INFO";
    case LogLevel::WARNING:
      return "WARN";
    case LogLevel::ERROR:
      return "ERROR";
    case LogLevel::DEBUG:
    default:
      return "DEBUG";
  }
}