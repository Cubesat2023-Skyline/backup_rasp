#pragma once

/*
████████╗██╗  ██╗███████╗ ██████╗ ███████╗      ██████╗  █████╗
╚══██╔══╝██║  ██║██╔════╝██╔═══██╗██╔════╝      ╚════██╗██╔══██╗
   ██║   ███████║█████╗  ██║   ██║███████╗█████╗ █████╔╝███████║
   ██║   ██╔══██║██╔══╝  ██║   ██║╚════██║╚════╝██╔═══╝ ██╔══██║
   ██║   ██║  ██║███████╗╚██████╔╝███████║      ███████╗██║  ██║
   ╚═╝   ╚═╝  ╚═╝╚══════╝ ╚═════╝ ╚══════╝      ╚══════╝╚═╝  ╚═╝

 File: CExecutor.cpp
 Author: Aroonsak Bootchai [AB]
===============================================================
Main executable which will control about runtime environment of the applications
on Linux system, controlled Arguments,

 Developer: Aroonsak Bootchai
 Project: SchoolSAT
 Date: 2022-Jun-12
 Version: 010
============================================================
*/

#include <fmt/format.h>

#include <iostream>
#include <string>
#include <unordered_map>

struct Args {
  uint8_t logLevel = 0;
};

Args parseArguments(int argc, char* argv[]) {
  Args args;

  for (int i = 1; i < argc; i += 2) {
    std::string option = argv[i];

    if (option == "-l" && i + 1 < argc) {
      args.logLevel = std::stoi(argv[i + 1]);
    }
  }
  return args;
}

class ParseArguments {
 public:
  std::unordered_map<std::string, std::string> list;

  ParseArguments(int argc, char* argv[]) {
    for (int i = 1; i < argc; i++) {
      std::string arg = argv[i];

      // Splitting the argument into key and value
      size_t equalPos = arg.find('=');
      std::string key = arg.substr(0, equalPos);
      std::string value = arg.substr(equalPos + 1);

      // Inserting the key-value pair into the unordered_map
      list[key] = value;
    }
  };
};