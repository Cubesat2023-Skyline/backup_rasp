#pragma once
/*
 File: CClalibrationConf.hpp
 Author: Sutee Chusri [SC]
===============================================================
 For raw data conversion to ensure the negative data can be
 stored and supported range via.RF transmittion

 Developer: Sutee Chusri
 Project: SchoolSAT
 Date: 2022-Nov-03
 Version: 100
===============================================================
*/

#include <iostream>
#include <unordered_map>

/*
 * Declare a global constant for calibration equation (Constant section only) as unordered map
 * only specify the TM that require the offset constant to convert the negative value (-) to positive integer
 * This require the syncing with TM spreadsheet (calibration equation (C value))
 * example
 * {303, {{12, 200}, {13, 90}}}
 * meaning
 * TM module ID 303
 * - TM Command ID 12
 * - Calibration EQ (C) = 200
 */
const std::unordered_map<int, std::unordered_map<int, int>> tmConstantOffset = {
    {303, {{12, 200000}}},
    {305, {{7, 30000}}},
    {3021, {{2, 200000}, {3, 200000}, {4, 200000}, {5, 25000}, {6, 25000}, {7, 25000}, {8, 480000000}, {9, 480000000}, {10, 480000000}, {11, 20000}, {13, 20000000}}},
    {3022, {{3, 1000000000}, {4, 1000000000}, {5, 1000000}}}};

/*
 * @brief get constant offset from pre-declared unordered map
 * @var moduleID:  unsigned integer
 * @var commandID: unsigned integer
 *
 * @return calibration constant (C value)
 * @return 0 if specified data is not found
 */
int getTmConstantOffset(uint16_t moduleID, uint8_t commandID) {
  if (tmConstantOffset.count(moduleID) && tmConstantOffset.at(moduleID).count(commandID)) {
    return tmConstantOffset.at(moduleID).at(commandID);
  }
  // Return 0 if index is not found
  return 0;
}