#pragma once

#include <string>

#ifndef _WIN32

#include <vector>

#endif // _WIN32

/**
 * @brief Encrypt given MAC address with the specified
 * secret key to generate a license string.
 *
 * @return a string containing license key
 */
std::string generate_license(
    const std::string& secret_key,
    const std::string& mac_addr
);

/**
 * @brief Encrypt given MAC address with the specified
 * secret key and write the generated license string into
 * the specified license file. The written string is in
 * the form of 'secret_key:license_key'.
 *
 * @return true if license file successfully generated;
 * false otherwise.
 */
bool generate_license(
    const std::string& secret_key,
    const std::string& mac_addr,
    const std::string& license_file
);

#ifndef _WIN32

/**
 * @brief Retrieve physical addresses of all network
 * interfaces available in the machine.
 *
 * @return true if mac addresses of the interfaces can
 * be retrieved successfully; false otherwise.
 */
bool get_all_mac_adresses(
    std::vector<std::string>& mac_addrs,
    std::string& error_msg
);

/**
 * @brief Check if the given license matches the specified
 * MAC address.
 *
 * @return true if the license verification is passed;
 * false otherwise.
 */
bool verify_license(
    const std::string& secret_key,
    const std::string& mac_addr,
    const std::string& license_str
);

/**
 * @brief Check if the given license matches any of MAC addresses 
 * of the available interfaces.
 *
 * @return true if the license verification is passed;
 * false otherwise.
 */
bool verify_license(
    const std::string& secret_key,
    const std::string& license_str
);

/**
 * @brief Read the license file and determine if the license string
 * in the file matches any of the MAC addresses available on the
 * machine.
 * @return true if the license verification is passed;
 * false otherwise.
 */
bool verify_license(
    const std::string& license_file
);

#endif //_WIN32