#pragma once

/*
████████╗██╗  ██╗███████╗ ██████╗ ███████╗      ██████╗  █████╗
╚══██╔══╝██║  ██║██╔════╝██╔═══██╗██╔════╝      ╚════██╗██╔══██╗
   ██║   ███████║█████╗  ██║   ██║███████╗█████╗ █████╔╝███████║
   ██║   ██╔══██║██╔══╝  ██║   ██║╚════██║╚════╝██╔═══╝ ██╔══██║
   ██║   ██║  ██║███████╗╚██████╔╝███████║      ███████╗██║  ██║
   ╚═╝   ╚═╝  ╚═╝╚══════╝ ╚═════╝ ╚══════╝      ╚══════╝╚═╝  ╚═╝

 File: ITTC.cpp
 Author: Aroonsak Bootchai [AB]
===============================================================
Main structure for TTC (Telemetry and Telecommand)
please note that the struct of data shall be related to the documents
https://drive.google.com/drive/u/0/folders/1u0ZkYuBGGmP1kSmudPR9p4BN9E7sliB3

 Developer: Aroonsak Bootchai
 Project: SchoolSAT
 Date: 2022-Jun-12
 Version: 100
============================================================
*/

#include <iomanip>
#include <iostream>
#include <string>
#include <unordered_map>
#include <vector>

enum class CtrlType : uint8_t
{
  TC_req,
  TC_ret,
  TM_req,
  TM_ret,
  TMR_req,
  TMR_ret
};

enum class _Datastate : uint8_t
{
  ACK,
  NACK,
  TIMEOUT
};

struct BroadcastValue {
  uint16_t moduleId;
  uint8_t commandID;
  int value;
};

struct TTCBroadcast {
  uint16_t moduleSrcID;
  uint16_t moduleDestID;
  uint8_t commandID;
  uint32_t requestTime;
  CtrlType ctrlType;
  uint8_t dataState;
  int32_t values[12];
};

struct TTCInternal {
  uint16_t moduleSrcID;
  uint16_t moduleDestID;
  uint8_t commandID;
  uint32_t requestTime;
  CtrlType ctrlType;
  int value;
};

TTCBroadcast sample_downlink_packet{.moduleSrcID = 308,
                                    .moduleDestID = 303,
                                    .commandID = 1,
                                    .requestTime = 1691377675,
                                    .ctrlType = CtrlType::TMR_ret,
                                    .dataState = 128,
                                    .values = {1212312, 121312313, 123123}};

TTCInternal sample_uplink_packet{.moduleSrcID = 308, .moduleDestID = 303, .commandID = 1, .requestTime = 1691377675, .ctrlType = CtrlType::TC_req, .value = 1};

// Function to convert struct to hex string
std::string StructToHexString(const void* data, size_t size) {
  std::stringstream ss;
  const unsigned char* byteData = reinterpret_cast<const unsigned char*>(data);
  for (size_t i = 0; i < size; ++i) {
    ss << std::hex << std::setfill('0') << std::setw(2) << static_cast<int>(byteData[i]);
  }
  return ss.str();
};

// Function to convert hex string to struct
void HexStringToStruct(const std::string& hexString, void* data, size_t size) {
  if (hexString.length() != size * 2) {
    std::cerr << "Hex string size doesn't match the struct size." << std::endl;
    return;
  }
  unsigned char* byteData = reinterpret_cast<unsigned char*>(data);

  for (size_t i = 0; i < size; ++i) {
    std::string byteStr = hexString.substr(i * 2, 2);
    byteData[i] = static_cast<unsigned char>(std::stoi(byteStr, nullptr, 16));
  }
};

// Function to set a value in a bit array at a specific bit shift position with a given bit length
void setValueInBitArray(int& bitArray, int value, uint8_t bitPosition, uint8_t bitLength) {
  // Create a bitmask with the desired bit length to clear the bits at the specified position
  int bitmask = (1 << bitLength) - 1;
  // Clear the bits in the bit array using the bitmask
  bitArray &= ~(bitmask << bitPosition);
  // Set the bits in the bit array with the value shifted to the correct position
  bitArray |= (value & bitmask) << bitPosition;
};

// Function to extract a value from a bit array at a specific bit shift position with a given bit
// length
template <typename T>
T getValueFromBitArray(const int bitArray, uint8_t bitPosition, uint8_t bitLength) {
  // Create a bitmask with the desired bit length to extract the bits at the specified position
  int bitmask = (1 << bitLength) - 1;
  // Extract the bits from the bit array using the bitmask and bit position
  int extractedBits = (bitArray >> bitPosition) & bitmask;
  // Shift the extracted bits to the rightmost position
  uint8_t shiftAmount = sizeof(T) * 8 - bitLength;
  extractedBits <<= shiftAmount;
  // Return the extracted value in the desired data type
  return static_cast<T>(extractedBits);
};