#pragma once
#include <iostream>
#include <unordered_map>

#include "ITTC.hpp"
/*
████████╗██╗  ██╗███████╗ ██████╗ ███████╗      ██████╗  █████╗
╚══██╔══╝██║  ██║██╔════╝██╔═══██╗██╔════╝      ╚════██╗██╔══██╗
   ██║   ███████║█████╗  ██║   ██║███████╗█████╗ █████╔╝███████║
   ██║   ██╔══██║██╔══╝  ██║   ██║╚════██║╚════╝██╔═══╝ ██╔══██║
   ██║   ██║  ██║███████╗╚██████╔╝███████║      ███████╗██║  ██║
   ╚═╝   ╚═╝  ╚═╝╚══════╝ ╚═════╝ ╚══════╝      ╚══════╝╚═╝  ╚═╝

 File: ITTC.cpp
 Owner: Aroonsak Bootchai [AB]
===============================================================
 Developer: Aroonsak Bootchai
 Project: SchoolSAT
 Date: 2022-Jun-12
 Version: 010
===============================================================
*/

struct PlanContent {
  CtrlType type;
  uint16_t moduleId;
  uint8_t commandId;
  int value;
};

struct Plan {
  std::string name;
  std::string description;
  uint32_t updateAt;
  std::unordered_map<int, PlanContent> commandList;
};

struct TMRContent {
  uint16_t moduleId;
  uint8_t commandId;
};

struct TmRecord {
  std::string name;
  std::string description;
  uint32_t updateAt;
  std::unordered_map<int, TMRContent> recordList;
};

// TODO: On progress to plan scheduler
// Plan MODE_0 {
//   .name = "",
//   .description = "",
//   .updateAt = 1691424010,
//   .commandList = {
//     0,{}
//   }
// }