#pragma once
/*
████████╗██╗  ██╗███████╗ ██████╗ ███████╗      ██████╗  █████╗
╚══██╔══╝██║  ██║██╔════╝██╔═══██╗██╔════╝      ╚════██╗██╔══██╗
   ██║   ███████║█████╗  ██║   ██║███████╗█████╗ █████╔╝███████║
   ██║   ██╔══██║██╔══╝  ██║   ██║╚════██║╚════╝██╔═══╝ ██╔══██║
   ██║   ██║  ██║███████╗╚██████╔╝███████║      ███████╗██║  ██║
   ╚═╝   ╚═╝  ╚═╝╚══════╝ ╚═════╝ ╚══════╝      ╚══════╝╚═╝  ╚═╝

 File: CMqueue.cpp
 Author: Aroonsak Bootchai [AB]
===============================================================
 [description here]

 Developer: Aroonsak Bootchai, Jeerasak Ruamnapaya
 Project: SchoolSAT
 Date: 2022-Jun-12
 Version: 300
===============================================================
*/

#include <fcntl.h>
#include <fmt/format.h>
#include <mqueue.h>
#include <sys/stat.h> /* For mode constants */
#include <unistd.h>

#include <functional>
#include <iostream>

#include "CLog.hpp"
#include "ITTC.hpp"

mq_attr MQ_ATTR = {.mq_flags = 0, .mq_maxmsg = 10, .mq_msgsize = 64, .mq_curmsgs = 0};
mq_attr MQ_ATTR_LOG = {.mq_flags = 0, .mq_maxmsg = 10, .mq_msgsize = sizeof(LogMessage), .mq_curmsgs = 0};
mq_attr MQ_ATTR_BOARDCAST = {.mq_flags = 0, .mq_maxmsg = 10, .mq_msgsize = 128, .mq_curmsgs = 0};  // Not in use

class CMqueue {
 private:
  /* data */
  std::string name = "/mqueue";

 public:
  struct mq_attr attr = MQ_ATTR;
  struct mq_attr attr_log = MQ_ATTR_LOG;
  struct mq_attr attr_boardcast = MQ_ATTR_BOARDCAST;
  int mode = -1;
  mqd_t mq_dest = -1;
  mqd_t mq_debug = -1;

  CMqueue(std::string _name) { name = _name; };

  ~CMqueue() {
    // Close the message queue
    if (mq_close(mq_dest) == -1) {
      std::cout << "failed to close mqueue" << std::endl << std::flush;
    }

    // Unlink the message queue
    if (mq_unlink(name.c_str()) == -1) {
      std::cout << "failed to unlink mqueue" << std::endl << std::flush;
    }
  };

  void Clear() { std::system(fmt::format("rm /dev/mqueue/{}", name).c_str()); }

  int OpenRead() {
    mode = 0;
    mq_dest = mq_open(name.c_str(), O_RDWR | O_CREAT, 0666, &attr);
    if (mq_dest == (mqd_t)-1) {
      return -1;
    }
    return 0;
  };

  int OpenReadLog() {
    mode = 0;
    mq_dest = mq_open(name.c_str(), O_RDWR | O_CREAT, 0666, &attr_log);
    if (mq_dest == (mqd_t)-1) {
      return -1;
    }
    return 0;
  };

  int OpenWrite() {
    mode = 1;
    mq_dest = mq_open(name.c_str(), O_RDWR | O_CREAT, 0666, &attr);
    return 0;
  };

  int OpenRDWR() {
    mode = 2;
    mq_dest = mq_open(name.c_str(), O_RDWR | O_CREAT, 0666, &attr);
    if (mq_dest == (mqd_t)-1) {
      return -1;
    }
    return 0;
  };

  int OpenBroadcast() {
    mode = 2;
    mq_dest = mq_open(name.c_str(), O_RDWR | O_CREAT, 0666, &attr_boardcast);
    if (mq_dest == (mqd_t)-1) {
      return -1;
    }
    return 0;
  };

  int Send(TTCInternal msg) {
    if (mode == 0) {
      return -1;
    }
    try {
      mq_send(mq_debug, reinterpret_cast<const char*>(&msg), sizeof(msg), 0);
    } catch (std::exception err) {
      std::cout << err.what() << std::endl << std::flush;
    }
    if (mq_send(mq_dest, reinterpret_cast<const char*>(&msg), sizeof(msg), 0) == -1) {
      perror("Error mq_send: Failed to send message to the queue.");
      return -1;
    }
    return 0;
  };

  int SendBroadcast(TTCBroadcast msg) {
    if (mode == 0) {
      return -1;
    }
    try {
      mq_send(mq_debug, (char*)&msg, sizeof(TTCBroadcast), 0);
    } catch (std::exception err) {
    }
    if (mq_send(mq_dest, (char*)&msg, sizeof(TTCBroadcast), 0) == -1) {
      perror("Error mq_send; Failed to send Boardcast message to the queue.");
      return -1;
    }
    return 0;
  };

  int Close() {
    if (mq_close(mq_dest) == -1) {
      std::cout << "failed to close mqueue" << std::endl << std::flush;
    }
    return 0;
  };
};
