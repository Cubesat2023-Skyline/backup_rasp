#pragma once
#include "../include/ITTC.hpp"

struct TMCommand {
  CtrlType ctrltype;
  uint16_t moduleId;
  uint8_t commandId;
  int32_t value;
};

std::unordered_map<std::string, TMCommand> Standby = {{"+0", {0, 303, 1, 0}}};

std::unordered_map<std::string, TMCommand> Preparation = {{"+0", {0, 303, 1, 0}}, {"+0", {0, 303, 0, 0}}};

std::unordered_map<std::string, TMCommand> Launch = {{"+1", {0, 303, 1, 0}}};

std::unordered_map<std::string, TMCommand> Operatiion = {{"+1", {0, 303, 1, 0}}};

std::unordered_map<std::string, TMCommand> Landing = {{"+1", {0, 303, 1, 0}}};

std::unordered_map<std::string, TMCommand> Landed = {{"+1", {0, 303, 1, 0}}};
