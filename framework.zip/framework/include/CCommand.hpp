#pragma once

/*
████████╗██╗  ██╗███████╗ ██████╗ ███████╗      ██████╗  █████╗
╚══██╔══╝██║  ██║██╔════╝██╔═══██╗██╔════╝      ╚════██╗██╔══██╗
   ██║   ███████║█████╗  ██║   ██║███████╗█████╗ █████╔╝███████║
   ██║   ██╔══██║██╔══╝  ██║   ██║╚════██║╚════╝██╔═══╝ ██╔══██║
   ██║   ██║  ██║███████╗╚██████╔╝███████║      ███████╗██║  ██║
   ╚═╝   ╚═╝  ╚═╝╚══════╝ ╚═════╝ ╚══════╝      ╚══════╝╚═╝  ╚═╝

 File: CCommand.cpp
 Author: Aroonsak Bootchai [AB]
===============================================================
CCommand is a library of utility functions designed to facilitate
the parsing and structuring of TTC (Telemetry and Telecommand) data.
This code provides a set of tools and functions that can be used to
process TTC messages, extract relevant information, and organize it
in a structured manner for further analysis or action.

 Developer: Aroonsak Bootchai
 Project: SchoolSAT
 Date: 2022-July-5
 Version: 011
===============================================================
*/
#include <csignal>
#include <functional>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

#include "CConfig.hpp"
#include "CDataPool.hpp"
#include "CLog.hpp"
#include "CMqueue.hpp"
#include "ITTC.hpp"
// clang-format off
// @formatter:off

struct Services {
  CMqueue*  MQ_Return;
  Logger*   Log;
  Datapool* Pool;
  Config*   config;
};

// Define a function type with two arguments
typedef std::function<void(TTCInternal*, Services*)> FunctionType;
typedef std::unordered_map<int, FunctionType> TTCType;
struct CommandThreadParams {
  CMqueue*  mq_return;
  CMqueue*  mq_request;
  CMqueue*  mq_logservice;
  TTCType*  tc_actions;
  TTCType*  tm_actions;
  Datapool* pool;
  Logger*   logger;
  Config*   config;
};

// clang-format on
// @formatter:on
// Function executed by the CommandThread
void* commandThreadFunc(void* arg) {
  CommandThreadParams* args = static_cast<CommandThreadParams*>(arg);
  TTCInternal* ttc{0};
  unsigned int priority;
  Services* services;
  services->MQ_Return = args->mq_return;
  services->Log = args->logger;
  while (true) {
    ssize_t bytesRead = mq_receive(args->mq_request->mq_dest, (char*)&ttc, sizeof(ttc), &priority);
    if (bytesRead == -1) {
      std::cerr << "Failed to receive message from the queue: " << strerror(errno) << std::endl;
      break;
    }
    switch (ttc->ctrlType) {
      case CtrlType::TC_req:
        if (args->tc_actions->contains((int)ttc->commandID)) {
          (*args->tc_actions)[ttc->commandID](ttc, services);
        }
        break;
      case CtrlType::TM_req:
        if (args->tm_actions->contains((int)ttc->commandID)) {
          (*args->tm_actions)[ttc->commandID](ttc, services);
        }
        break;
    }
  }
  pthread_exit(nullptr);
};

void signalHandler(int signum) {
  std::cout << "Interrupt signal (" << signum << ") received.\n";
  exit(signum);
};

void WaitDebug(CommandThreadParams* args) {
  std::thread t1([=]() {
    std::signal(SIGINT, signalHandler);
    std::string text_in;
    while (true) {
      std::cin >> text_in;
      std::vector<std::string> splitText;
      std::stringstream ss(text_in);
      std::string token;

      while (std::getline(ss, token, ';')) {
        splitText.push_back(token);
      }
      TTCInternal* ttc = {0};
      Services* services = {0};
      services->MQ_Return = args->mq_return;
      services->Log = args->logger;
      services->Pool = args->pool;

      std::cout << sizeof(args->tc_actions) << std::endl << std::flush;
      std::cout << sizeof(args->tm_actions) << std::endl << std::flush;

      if (splitText[0] == "TC" || splitText[0] == "tc" && splitText.size() == 3) {
        std::cout << "PROCESS TC" << std::endl << std::flush;
        ttc->ctrlType = CtrlType::TC_req;
        ttc->commandID = std::stoi(splitText[1]);
        ttc->value = std::stoi(splitText[2]);
        std::cout << args->tm_actions->size() << std::endl << std::flush;
        if (args->tc_actions->contains((int)std::stoi(splitText[1]))) {
          (*args->tc_actions)[(int)std::stoi(splitText[1])](ttc, services);
        } else {
          std::cerr << "cannot find the TCs\n" << std::flush;
        }
      } else if (splitText[0] == "TM" || splitText[0] == "tm") {
        std::cout << "PROCESS TM" << std::endl << std::flush;
        ttc->ctrlType = CtrlType::TM_req;
        ttc->commandID = std::stoi(splitText[1]);
        ttc->value = 0;
        if (args->tm_actions->contains((int)std::stoi(splitText[1]))) {
          (*args->tm_actions)[(int)std::stoi(splitText[1])](ttc, services);
        } else {
          std::cerr << "cannot find the TMs\n" << std::flush;
        }
      } else {
        std::cerr << "REJECT!" << std::endl << std::flush;
      }
    }
    return;
  });
  t1.detach();
}
