/*
████████╗██╗  ██╗███████╗ ██████╗ ███████╗      ██████╗  █████╗
╚══██╔══╝██║  ██║██╔════╝██╔═══██╗██╔════╝      ╚════██╗██╔══██╗
   ██║   ███████║█████╗  ██║   ██║███████╗█████╗ █████╔╝███████║
   ██║   ██╔══██║██╔══╝  ██║   ██║╚════██║╚════╝██╔═══╝ ██╔══██║
   ██║   ██║  ██║███████╗╚██████╔╝███████║      ███████╗██║  ██║
   ╚═╝   ╚═╝  ╚═╝╚══════╝ ╚═════╝ ╚══════╝      ╚══════╝╚═╝  ╚═╝

 File: ADHT22.cpp
 Author: Jeerasak Ruamnapaya [JR]
===============================================================
 This software is a Secondary Payload. which is used for DHT22 module
 The DHT22 module can measure the following sensor values:
  1. Temperature sensor
  2. Humidity sensor

 Telecommand (TC):
 For terminal input -> TC;[x];0
  [1]: Start sampling all sensors, start logging and feeding to data pool
  [2]: Stop sampling all sensors, stop logging and feeding to data pool

 Telemetry (TM):
 For terminal input -> TM;[x];0
  [1]: Return DHT22 status (0: Ready, 1: Sampling, 2: Disconnected, 3:Unknown error)
  [2]: Return 16 bit signed integer Temperature
  [3]: Return 16 bit unsigned integer Humidity
  [4]: Return software version

 Developer: Jeerasak Ruamnapaya [JR]
 Project: SchoolSAT
 Date: 2023-Jun-30
 Version: 1.04
===============================================================
*/

/**
 * [x] application shall execute with minimum required arguments
 * [x] application shall able to load config file as mentioned from aguments
 * [x] the config file shall be shown registered TC and registered TM (which
 * validated from FSW)
 * [x] the TC and TM in unordered_map (which will able to
 * use find key)
 * [ ] every switch, boolean, shared data, shared value can be in
 * form of atomic & shared pointers
 * - Aroonsak Bootchai
 */

/** At main thread,
 * 1 ) [X] read and check arguments is correct from defined
 * 2 ) [X] read file from argument, the config shall be parsed from the file
then close file
 * 3 ) [X] read config,
 * [ ] if key have __TC__, parse the line by TC::parse then push TC to
unordered_map TCTable
 * [ ] if key have __TM__, parse the line by TM::parse then push TM to
unordered_map TMTable
 * [ ] else push the config to unordered_map Config
 * 4 ) [x] from config, parse the line by Config::parse then push Config to
unordered_map ConfigTable
 * 5 ) [x] TMFunction (unordered_map)
 * 6 ) [x] TCFunction (unordered_map)
 * 7 ) [x] detach a thread, Command Thread with (reference)TMTable,
(reference)TCTable, (reference)TMFUnction, (reference)TCFunction and Config as
arguments to thread
 * 8 ) [x] while loop to prevent the main thread stopped
 * - Aroonsak Bootchai
 */

/** 1 [ ] detached thread (Pthread) named Command thread, reading message from
 *message queue (using Config["mqueue"] as name ) and parse that to MsgPacket
 struct (message packet is a struct that  ...), after parsed,
 * [ ] if MsgPacket.ctrlType == 0 then find MsgPacket.commandID in TMFunction,
 exec TCFunc(MsgPacket)
 * [ ] if MsgPacket.ctrlType == 2 then find MsgPacket.commandID in TCFunction,
 exec TMFunc(MsgPacket)
 * - Aroonsak Bootchai
 **/

#include <fcntl.h>
#include <fmt/format.h>
#include <mqueue.h>
#include <sys/mman.h>
#include <unistd.h>

#include <atomic>
#include <chrono>
#include <fstream>
#include <functional>
#include <iostream>
#include <map>
#include <string>
#include <thread>
#include <vector>

#include "../include/CCommand.hpp"
#include "../include/CConfig.hpp"
#include "../include/CDataPool.hpp"
#include "../include/CExecutor.hpp"
#include "../include/CLog.hpp"
#include "../include/CMqueue.hpp"
#include "../include/ITTC.hpp"

// =============================== DHT22 Value ===============================
#include "../lib/rpi_dht22.h"

std::atomic<uint8_t> DHT_sampling_state = 0;
std::atomic<uint8_t> DHT_harness_check = 0;

#define START_ACCEPT 0
#define START_REJECT 1
#define STOP_ACCEPT 0
#define STOP_REJECT 1

#define CELSIUS_DEFAULT 32767
#define HUMIDITY_DEFAULT 65535
#define SOFTWARE_VERSION 104    // Version 1.04
#define DHT_SAMPLING_RATE 1000  // In millisecond
#define CONST_CALIBRATION_EQ_TEMP 2000

uint8_t DHT_status = 0;
uint8_t DHT_disTime = 0;  // Check time disconnect

rpi_dht22 dht22;

// ================================= TC Code =================================
int DHT_TC_1(const TTCInternal* ttc, const Services* services) {
  TTCInternal _ttc = *ttc;
  _ttc.ctrlType = CtrlType::TC_ret;

  // Check Status
  dht22.Init();
  if (dht22.WiringStatus() == -1) {
    DHT_harness_check = 0;
    DHT_status = 2;
  } else if (dht22.WiringStatus() != -1 && DHT_sampling_state == 1) {
    DHT_harness_check = 1;
    DHT_status = 1;
  } else if (dht22.WiringStatus() != -1 && DHT_sampling_state == 0) {
    DHT_harness_check = 1;
    DHT_status = 0;
  } else {
    DHT_status = 3;
  }

  // Harness cable Check: Connected and Thread check
  if (DHT_harness_check == 1 && DHT_sampling_state == 0) {
    DHT_sampling_state = 1;
    DHT_status = 1;

    _ttc.value = START_ACCEPT;
    services->MQ_Return->Send(_ttc);

    services->Log->log(fmt::format("TC_1 Accept: {}", _ttc.value));

    std::thread t1([=]() {
      try {
        // int sensors data out
        int16_t celsius = CELSIUS_DEFAULT;
        uint16_t humidity = HUMIDITY_DEFAULT;

        // Float sensors data in
        float _celsius = CELSIUS_DEFAULT;
        float _humidity = HUMIDITY_DEFAULT;

        // Throw function
        bool throw_exception;
        uint8_t cable_status = 0;

        // loop data sampling
        while (DHT_sampling_state == 1) {
          if (dht22.WiringStatus() == -1) {
            cable_status = 2;
            DHT_disTime++;
            services->Pool->Set(1, cable_status);
            if (DHT_disTime >= 5) {
              throw throw_exception;
            }
          } else {
            cable_status = 1;
            DHT_disTime = 0;
            services->Pool->Set(1, cable_status);
          }
          dht22.Begin();
          celsius = dht22.GetTemperature();
          humidity = dht22.GetHumidity();

          // store data to datapool as [tmID] = [value]
          services->Pool->Set(2, celsius + CONST_CALIBRATION_EQ_TEMP);
          services->Pool->Set(3, humidity);

          // Print Data sensor
          // services->Log->log(fmt::format("Temp(C): {}\t| Humidity(%RH): {}", celsius / 10.0, humidity / 10.0));

          // Delay minimum 1000 ms
          std::this_thread::sleep_for(std::chrono::milliseconds(DHT_SAMPLING_RATE));
        }
      }

      // Catch Lost connect function
      catch (bool throw_exception) {
        DHT_harness_check = 0;
        DHT_sampling_state = 0;
        services->Log->log(LogLevel::ERROR, "Lost Connection");
      }
      services->Log->log(LogLevel::INFO, "Thread Close");
    });
    t1.detach();
  }

  // TC_1 Reject: Disconnected check TM_1 again
  else if (DHT_harness_check == 0 && DHT_sampling_state == 0) {
    DHT_status = 2;
    services->Pool->Set(1, DHT_status);
    _ttc.value = START_REJECT;
    services->MQ_Return->Send(_ttc);

    services->Log->log(LogLevel::WARNING, "TC_1 Reject: Disconnected");
  }

  // TC_1 Reject: Sampling
  else if (DHT_harness_check == 1 && DHT_sampling_state == 1) {
    DHT_status = 1;
    services->Pool->Set(1, DHT_status);
    _ttc.value = START_REJECT;
    services->MQ_Return->Send(_ttc);

    services->Log->log(LogLevel::WARNING, "TC_1 Reject: Sampling");
  }

  // TC_1 Reject: Unknow Error case
  else {
    DHT_status = 3;
    services->Pool->Set(1, DHT_status);
    _ttc.value = START_REJECT;
    services->MQ_Return->Send(_ttc);

    services->Log->log(LogLevel::ERROR, "TC_1 Reject: Unknow Error");
  }
  return 0;
}

int DHT_TC_2(const TTCInternal* ttc, const Services* services) {
  TTCInternal _ttc = *ttc;
  _ttc.ctrlType = CtrlType::TC_ret;

  if (DHT_sampling_state == 1) {
    _ttc.value = STOP_ACCEPT;
    DHT_sampling_state = 0;

    services->Log->log(fmt::format("TC_2 Accept: {}", _ttc.value));
  } else {
    _ttc.value = STOP_REJECT;

    services->Log->log(fmt::format("TC_2 Reject: {}", _ttc.value));
  }
  DHT_status = 0;
  services->Pool->Set(1, DHT_status);

  services->MQ_Return->Send(_ttc);
  return 0;
}

// ================================= TM Code =================================
int DHT_TM_1(const TTCInternal* ttc, const Services* services) {
  // Check Status
  dht22.Init();
  if (dht22.WiringStatus() == -1) {
    DHT_harness_check = 0;
    DHT_status = 2;
  } else if (dht22.WiringStatus() != -1 && DHT_sampling_state == 1) {
    DHT_harness_check = 1;
    DHT_status = 1;
  } else if (dht22.WiringStatus() != -1 && DHT_sampling_state == 0) {
    DHT_harness_check = 1;
    DHT_status = 0;
  } else {
    DHT_status = 3;
  }

  services->Pool->Set(1, DHT_status);

  // Log Status
  if (DHT_status == 2) {
    services->Log->log(LogLevel::WARNING, "TM_1: Disconnected");
  } else if (DHT_status == 1) {
    services->Log->log(LogLevel::INFO, "TM_1: Sampling");
  } else if (DHT_status == 0) {
    services->Log->log(LogLevel::INFO, "TM_1: Standby");
  } else {
    services->Log->log(LogLevel::ERROR, "TM_1: Unknow Error");
  }

  TTCInternal _ttc = *ttc;
  _ttc.ctrlType = CtrlType::TM_ret;
  _ttc.value = services->Pool->Get(1);
  services->MQ_Return->Send(_ttc);

  services->Log->log(fmt::format("TM_1: code {}", _ttc.value));
  return 0;
}

int DHT_TM_2(const TTCInternal* ttc, const Services* services) {
  if (DHT_sampling_state == 0) {
    services->Pool->Set(2, CELSIUS_DEFAULT);
  }
  TTCInternal _ttc = *ttc;
  _ttc.ctrlType = CtrlType::TM_ret;
  _ttc.value = services->Pool->Get(2);
  services->MQ_Return->Send(_ttc);

  services->Log->log(fmt::format("Temperature(C): {}", _ttc.value));
  return 0;
}

int DHT_TM_3(const TTCInternal* ttc, const Services* services) {
  if (DHT_sampling_state == 0) {
    services->Pool->Set(3, HUMIDITY_DEFAULT);
  }
  TTCInternal _ttc = *ttc;
  _ttc.ctrlType = CtrlType::TM_ret;
  _ttc.value = services->Pool->Get(3);
  services->MQ_Return->Send(_ttc);

  services->Log->log(fmt::format("Humidity(%RH): {}", _ttc.value));
  return 0;
}

int DHT_TM_4(const TTCInternal* ttc, const Services* services) {
  TTCInternal _ttc = *ttc;
  _ttc.ctrlType = CtrlType::TM_ret;
  _ttc.value = SOFTWARE_VERSION;
  services->MQ_Return->Send(_ttc);

  services->Log->log(fmt::format("Software Version: {}", _ttc.value));
  return 0;
}

// ================================ Main code ================================
int main(int argc, char* argv[]) {
  auto fsw_pool = new Datapool("/303");
  auto logger = new Logger();
  logger->setLogLevel(fsw_pool->Get(5));
  logger->setModuleID(3062);
  logger->setLogMQName("/log.sub");
  logger->setManualMQService();

  Datapool* pool = new Datapool("/306.2");
  CMqueue* mq_request = new CMqueue("/306.2");
  CMqueue* mq_return = new CMqueue("/realtime");
  CMqueue* mq_log = new CMqueue("/log.sub");

  if (mq_return->OpenWrite() == -1) {
    logger->log(LogLevel::ERROR, "Failed to open message queue");
    return EXIT_FAILURE;
  } else {
    logger->log(LogLevel::INFO, "connected MQ_Return");
  }

  if (mq_request->OpenRead() == -1) {
    logger->log(LogLevel::ERROR, "Failed to open message queue");
    return EXIT_FAILURE;
  } else {
    logger->log(LogLevel::INFO, "connected MQ_Request");
  }

  if (mq_log->OpenWrite() == -1) {
    logger->log(LogLevel::ERROR, "Failed to open message queue");
    return EXIT_FAILURE;
  } else {
    logger->log(LogLevel::INFO, "connected MQ_Logger");
  }

  // ========================== Start subsystem code ==========================
  std::unordered_map<int, std::function<void(TTCInternal*, Services*)>> tc_actions;
  std::unordered_map<int, std::function<void(TTCInternal*, Services*)>> tm_actions;

  // Initialize Setup wiringpi GPIO and Check status
  dht22.Init();

  // tc_actions[<<commandID>>] = function()
  tc_actions[1] = DHT_TC_1;
  tc_actions[2] = DHT_TC_2;

  // tm_actions[<<commandID>>] = function()
  tm_actions[1] = DHT_TM_1;
  tm_actions[2] = DHT_TM_2;
  tm_actions[3] = DHT_TM_3;
  tm_actions[4] = DHT_TM_4;

  // ============================== FSW Section ==============================
  TTCInternal message;
  unsigned int priority;
  Services* services = new Services;
  services->MQ_Return = mq_return;
  services->Log = logger;
  services->Pool = pool;

  while (true) {
    ssize_t bytes = mq_receive(mq_request->mq_dest, reinterpret_cast<char*>(&message), 64, NULL);
    if (bytes == -1) {
    } else {
      TTCInternal* msg = new TTCInternal;
      *msg = message;
      switch (message.ctrlType) {
        case CtrlType::TC_req:
          if (tc_actions.contains((int)message.commandID)) {
            tc_actions[message.commandID](msg, services);
          }
          break;
        case CtrlType::TM_req:
          if (tm_actions.contains((int)message.commandID)) {
            tm_actions[message.commandID](msg, services);
          }
          break;
      }
    }
  }
  return 0;
}
