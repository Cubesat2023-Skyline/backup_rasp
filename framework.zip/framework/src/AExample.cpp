/*
████████╗██╗  ██╗███████╗ ██████╗ ███████╗      ██████╗  █████╗
╚══██╔══╝██║  ██║██╔════╝██╔═══██╗██╔════╝      ╚════██╗██╔══██╗
   ██║   ███████║█████╗  ██║   ██║███████╗█████╗ █████╔╝███████║
   ██║   ██╔══██║██╔══╝  ██║   ██║╚════██║╚════╝██╔═══╝ ██╔══██║
   ██║   ██║  ██║███████╗╚██████╔╝███████║      ███████╗██║  ██║
   ╚═╝   ╚═╝  ╚═╝╚══════╝ ╚═════╝ ╚══════╝      ╚══════╝╚═╝  ╚═╝

 File: AGPS.cpp
 Author: Thirasak Phonmat
===============================================================
 GPS Sensors software.

 Developer: Thirasak Phonmat, Aroonsak Bootchai
 Project: SchoolSAT
 Date: 2023-Aug-16
 Version: 103
===============================================================
[update - date 09/08/2566]
-bug fixs *problem-> TC Can't Start
-status function fixs
-disable LOG Thread (disable thread4)
*/

#include <fcntl.h>
#include <fmt/format.h>
#include <mqueue.h>
#include <sys/mman.h>
#include <unistd.h>

#include <atomic>
#include <cctype>
#include <chrono>
#include <fstream>
#include <functional>
#include <iostream>
#include <map>
#include <string>
#include <thread>
#include <vector>

// Additoinal Library for GPS sub-system
#include <errno.h>
#include <string.h>
#include <termios.h>
#include <time.h>

#include <cmath>
#include <iomanip>
#include <sstream>

#include "../include/CCommand.hpp"
#include "../include/CConfig.hpp"
#include "../include/CDataPool.hpp"
#include "../include/CExecutor.hpp"
#include "../include/CLog.hpp"
#include "../include/CMqueue.hpp"
#include "../include/ITTC.hpp"

#define x_million 1000000
#define x_thousand 1000
#define x_hundred 100

#define default_value_lat 999999999
#define default_value_lon 999999999
#define default_value_unix_time 0
#define default_value_speed 0
#define default_value_cog 44444
#define default_value_alt 999999
#define default_value_sat_used 0
#define default_value_hdop 9999

int serial_port = open("/dev/ttyS0", O_RDONLY | O_NOCTTY);
char read_buf[256];
std::string format1 = "$GNRMC";
std::string format2 = "$GNGGA";
std::string inputString;                   // a string to hold incoming data
std::atomic<bool> string_complete{false};  // whether the string is complete

std::atomic<int32_t> LATITUDE_DD_ATOM{default_value_lat};
std::atomic<int32_t> LONGITUDE_DD_ATOM{default_value_lon};
std::atomic<uint32_t> UNIX_TIME_ATOM{default_value_unix_time};
std::atomic<uint16_t> SPEED_ATOM{default_value_speed};
std::atomic<uint16_t> COG_ATOM{default_value_cog};
std::atomic<int32_t> ALTITUDE_MSL_ATOM{default_value_sat_used};
std::atomic<uint16_t> SATELLITE_USED_ATOM{default_value_sat_used};
std::atomic<uint16_t> HDOP_ATOM{default_value_hdop};

std::atomic<bool> GPS_UART_STATUS_ATOM{false};
std::atomic<bool> GPS_STATUS_ATOM{0};
std::atomic<int> GPS_FIXED_STATUS_ATOM{0};
std::atomic<int> GPS_CURRENT_STATUS_ATOM{0};
std::atomic<int> GPS_WIRE_CHECK{0};
std::atomic<uint16_t> thread_status{0};
std::atomic<uint16_t> GPS_SOFTWARE_VERSION{102};

bool isNumber(const std::string& str) {
  for (char c : str) {
    if (!std::isdigit(c) && c != '.' && c != '-') {
      return false;
    }
  }
  return true;
}

// Setup UART Communication Port Function
int GPS_uartSetup() {
  struct termios tty;
  if (tcgetattr(serial_port, &tty) != 0) {
    printf("Error %i from tcgetattr: %s\n", errno, strerror(errno));
    GPS_UART_STATUS_ATOM = false;
  } else {
    GPS_UART_STATUS_ATOM = true;
  }
  tty.c_cflag &= ~PARENB;
  tty.c_cflag &= ~CSTOPB;
  tty.c_cflag &= ~CSIZE;
  tty.c_cflag |= CS8;
  tty.c_cflag &= ~CRTSCTS;
  tty.c_cflag |= CREAD | CLOCAL;
  tty.c_lflag &= ~ICANON;
  tty.c_lflag &= ~ECHO;
  tty.c_lflag &= ~ECHOE;
  tty.c_lflag &= ~ECHONL;
  tty.c_lflag &= ~ISIG;
  tty.c_iflag &= ~(IXON | IXOFF | IXANY);
  tty.c_iflag &= ~(IGNBRK | BRKINT | PARMRK | ISTRIP | INLCR | IGNCR | ICRNL);
  tty.c_oflag &= ~OPOST;
  tty.c_oflag &= ~ONLCR;
  tty.c_cc[VTIME] = 10;
  tty.c_cc[VMIN] = 0;
  cfsetispeed(&tty, B9600);
  cfsetospeed(&tty, B9600);
  if (tcsetattr(serial_port, TCSANOW, &tty) != 0) {
    printf("Error %i from tcsetattr: %s\n", errno, strerror(errno));
    GPS_UART_STATUS_ATOM = false;
  } else {
    GPS_UART_STATUS_ATOM = true;
  }
  return 0;
}

// S.C. Added 2023-Oct-23
// Function to convert time and date to Unix timestamp
std::time_t convertToUnixTime(float time, int32_t date) {
  // Extract individual components from the provided float time
  int hours = static_cast<int>(time) / 10000;
  int minutes = static_cast<int>(time) % 10000 / 100;
  int seconds = static_cast<int>(time) % 100;

  // Assuming the date is in DDMMYY format
  int year = (date % 100) + 2000;
  int month = (date % 10000) / 100;
  int day = date / 10000;

  // Create a time_point using std::tm struct
  std::tm tmStruct;
  tmStruct.tm_sec = seconds;
  tmStruct.tm_min = minutes;
  tmStruct.tm_hour = hours;
  tmStruct.tm_mday = day;
  tmStruct.tm_mon = month - 1;     // Month is 0-based in tm struct
  tmStruct.tm_year = year - 1900;  // Years since 1900 in tm struct
  tmStruct.tm_isdst = -1;          // Daylight saving time not set
  std::time_t unixTime = std::mktime(&tmStruct);

  return unixTime;
}

// S.C. Added 2023-Oct-23
// Function to split a string based on a delimiter and store the substrings into a vector
std::vector<std::string> split(const std::string& input, char delimiter) {
  std::vector<std::string> tokens;
  std::istringstream iss(input);
  std::string token;
  while (std::getline(iss, token, delimiter)) {
    tokens.push_back(token);
  }
  return tokens;
}

// S.C. Added 2023-Oct-23
// Function to extract parameters from GPS data using split method
void extractParamsSplit(const std::string& data) {
  /*
  std::atomic<int32_t> LATITUDE_DD_ATOM{default_value_lat};
  std::atomic<int32_t> LONGITUDE_DD_ATOM{default_value_lon};
  std::atomic<uint32_t> UNIX_TIME_ATOM{default_value_unix_time};
  std::atomic<uint16_t> SPEED_ATOM{default_value_speed};
  std::atomic<uint16_t> COG_ATOM{default_value_cog};
  std::atomic<int32_t> ALTITUDE_MSL_ATOM{default_value_sat_used};
  std::atomic<uint16_t> SATELLITE_USED_ATOM{default_value_sat_used};
  std::atomic<uint16_t> HDOP_ATOM{default_value_hdop};

  std::atomic<bool> GPS_UART_STATUS_ATOM{false};
  std::atomic<bool> GPS_STATUS_ATOM{0};
  std::atomic<int> GPS_FIXED_STATUS_ATOM{0};
  std::atomic<int> GPS_CURRENT_STATUS_ATOM{0};
  std::atomic<int> GPS_WIRE_CHECK{0};
  */
  float timeF;
  int32_t dateI32;
  float magneticVariationF;
  uint16_t checksumUI16;

  std::vector<std::string> tokens = split(data, ',');

  if (tokens[0] == "$GNRMC") {
    timeF = std::stof(tokens[1]);
    GPS_STATUS_ATOM = tokens[2].empty() ? 2 : (tokens[2][0] == 'V' ? 0 : (tokens[2][0] == 'A' ? 1 : 2));  // No data or data not 'V' / 'A' assign 2, 'V' assigns 0, 'A' assigns 1
    LATITUDE_DD_ATOM =
        tokens[3].empty()
            ? default_value_lat
            : (tokens[4][0] == 'N' ? (floor(std::stof(tokens[3]) / 100) + (std::stof(tokens[3].substr(2, 8)) / 60) * x_million)
                                   : (tokens[4][0] == 'S' ? (floor(std::stof(tokens[3]) / 100) + (std::stof(tokens[3].substr(2, 8)) / 60) * x_million) * (-1) : default_value_lat));
    LONGITUDE_DD_ATOM =
        tokens[5].empty()
            ? default_value_lon
            : (tokens[6][0] == 'E' ? (floor(std::stof(tokens[5]) / 100) + (std::stof(tokens[5].substr(2, 8)) / 60) * x_million)
                                   : (tokens[6][0] == 'W' ? (floor(std::stof(tokens[5]) / 100) + (std::stof(tokens[5].substr(2, 8)) / 60) * x_million) * (-1) : default_value_lon));
    SPEED_ATOM = tokens[7].empty() ? 0 : (std::stof(tokens[7]) * 0.514) * x_thousand;
    COG_ATOM = tokens[8].empty() ? ((float)default_value_cog / (float)x_hundred) : (std::stof(tokens[8]) * x_hundred);
    dateI32 = std::stoi(tokens[9]);
    magneticVariationF = tokens[10].empty() ? 0.0f : std::stof(tokens[10]);
    checksumUI16 = std::stoi(tokens[11], 0, 16);
    UNIX_TIME_ATOM = convertToUnixTime(timeF, dateI32);
  } else if (tokens[0] == "$GNGGA") {
    timeF = std::stof(tokens[1]);
    LATITUDE_DD_ATOM =
        tokens[2].empty()
            ? default_value_lat
            : (tokens[3][0] == 'N' ? (floor(std::stof(tokens[2]) / 100) + (std::stof(tokens[2].substr(2, 8)) / 60) * x_million)
                                   : (tokens[3][0] == 'S' ? (floor(std::stof(tokens[2]) / 100) + (std::stof(tokens[2].substr(2, 8)) / 60) * x_million) * (-1) : default_value_lat));
    LONGITUDE_DD_ATOM =
        tokens[4].empty()
            ? default_value_lon
            : (tokens[5][0] == 'E' ? (floor(std::stof(tokens[4]) / 100) + (std::stof(tokens[4].substr(2, 8)) / 60) * x_million)
                                   : (tokens[5][0] == 'W' ? (floor(std::stof(tokens[4]) / 100) + (std::stof(tokens[4].substr(2, 8)) / 60) * x_million) * (-1) : default_value_lon));
    GPS_STATUS_ATOM = GPS_STATUS_ATOM =
        tokens[2].empty() ? 2 : (tokens[2][0] == 'V' ? 0 : (tokens[2][0] == 'A' ? 1 : 2));  // No data or data not 'V' / 'A' assign 2, 'V' assigns 0, 'A' assigns 1
    /*To Do
    check and add correct data into the atomic*/
    SPEED_ATOM = tokens[7].empty() ? 0 : (std::stof(tokens[7]) * 0.514) * x_thousand;
    magneticVariationF = tokens[10].empty() ? 0.0f : std::stof(tokens[10]);
    checksumUI16 = std::stoi(tokens[11], 0, 16);
    UNIX_TIME_ATOM = UNIX_TIME_ATOM + 1;  // For GNGGA format, Unix time is not available, increment the current time instead
  } else {
    std::cout << "Unsupported/Invalid GPS data format." << std::endl;
  }
}

// GPS data processing function
int GPS_Operate() {
  time_t rawtime;
  struct tm* timeinfo;
  /* get current timeinfo: */
  time(&rawtime);  // or: rawtime = time(0);
  /* convert to struct: */
  timeinfo = gmtime(&rawtime);

  // RMC variable
  std::string inChar;
  std::string Message_protocal;
  std::string mid1;  // message ID1 ->> RMC
  std::string time;
  std::string status;
  std::string lat;
  std::string nsIndicator;
  std::string lon;
  std::string ewIndicator;
  std::string speed;
  std::string cog;
  std::string date;
  std::string empty1;
  std::string empty2;
  std::string modeChecksum;
  std::string daySub = "0";
  std::string monthSub = "0";
  std::string yearSub = "0";
  std::string timeHrSub = "0";
  std::string timeMinSub = "0";
  std::string timeSecSub = "0";

  // GGA variable
  std::string mid2;  // message ID2 ->> GGA
  std::string time2;
  std::string lat2;
  std::string nsIndicator2;
  std::string lon2;
  std::string ewIndicator2;
  std::string positionFix;
  std::string satUsed;
  std::string hdop;
  std::string altitudeMSL;
  std::string altitudeUnit;
  std::string geoidSep;
  std::string geoidSepUnit;
  std::string emptyDGPS;
  std::string modeChecksum2;

  while (thread_status == 1) {
    read(serial_port, &read_buf, 255);
    inChar = read_buf;
    inputString += read_buf;

    if (std::string(read_buf) == "") {
      GPS_WIRE_CHECK = 0;
    } else {
      GPS_WIRE_CHECK = 1;
    }

    if (inChar == "\n") {
      string_complete = true;

      if (string_complete) {
        Message_protocal = inputString.substr(0, 6);
        if (Message_protocal == format1) {
          printf("AGPS: raw input = [%s\n", inputString.c_str());
          fflush(stdout);

          printf("\tAGPS: Detect format [%s]\n", Message_protocal.c_str());
          fflush(stdout);
          // Split the data using a comma as the delimiter
          std::stringstream ss(inputString);
          std::string token;
          std::vector<std::string> tokens;

          while (getline(ss, token, ',')) {
            if (token.size() < 64) {
              tokens.push_back(token);
            };
          }

          try {
            // clang-format off
            // @formatter:off
            // Store the values in separate variables
            mid1         = tokens.size() <= 0           ? "0" : tokens[0];
            time         = tokens.size() <= 1           ? "0" : tokens[1];
            
            printf("\tAGPS: dbg > time(%d) [%s]\ttoken: %s\n", time.length(), time.c_str(), tokens[1].c_str());
            printf("\tAGPS: dbg > time [%s]:[%s]:[%s]\n", time.substr(0, 2), time.substr(0, 2), time.substr(0, 2).c_str());
            fflush(stdout);
            
            status       = tokens.size() <= 2           ? "0" : tokens[2];
            lat          = tokens.size() <= 3           ? "" : tokens[3];
            if (lat == "") {
              lat = std::to_string(default_value_lat);
            }
            nsIndicator  = tokens.size() <= 4           ? "0" : tokens[4];
            lon          = tokens.size() <= 5           ? "" : tokens[5];
            if (lon == "") {
              lon = std::to_string(default_value_lon);
            }
            ewIndicator  = tokens.size() <= 6           ? "0" : tokens[6];
            speed        = tokens.size() <= 7           ? "0" : tokens[7];
            cog          = tokens.size() <= 8           ? "" : tokens[8];
            if (cog == "") {
              cog = std::to_string((float)default_value_cog / (float)x_hundred);
            }
            date         = tokens.size() <= 9           ? "0" : tokens[9];
            empty1       = tokens.size() <= 10          ? "0" : tokens[10];
            empty2       = tokens.size() <= 11          ? "0" : tokens[11];
            modeChecksum = tokens.size() <= 12          ? "0" : tokens[12];

            // clang-format on
            // @formatter:on

            daySub = "0";
            monthSub = "0";
            yearSub = "0";
            if (date != "0" && date.length() == 6) {
              daySub = date.substr(0, 2).c_str();
              monthSub = date.substr(2, 2).c_str();
              yearSub = date.substr(4, 2).c_str();
            }

            timeHrSub = "0";
            timeMinSub = "0";
            timeSecSub = "0";
            if (time != "0" && time.length() >= 6) {
              timeHrSub = time.substr(0, 2).c_str();
              timeMinSub = time.substr(2, 2).c_str();
              timeSecSub = time.substr(4, 2).c_str();
            }

            if (nsIndicator == "N" && lat != std::to_string(default_value_lat)) {
              LATITUDE_DD_ATOM = ((floor(stof(lat) / 100)) + (stof(lat.substr(2, 8)) / 60)) * x_million;
            } else if (nsIndicator == "S" && lat != std::to_string(default_value_lat)) {
              LATITUDE_DD_ATOM = (((floor(stof(lat) / 100)) + (stof(lat.substr(2, 8)) / 60)) * x_million) * (-1);
            } else {
              LATITUDE_DD_ATOM = default_value_lat;
            }

            if (ewIndicator == "E" && lon != std::to_string(default_value_lon)) {
              LONGITUDE_DD_ATOM = ((floor(stof(lon) / 100)) + (stof(lon.substr(3, 8)) / 60)) * x_million;
            } else if (ewIndicator == "W" && lon != std::to_string(default_value_lon)) {
              LONGITUDE_DD_ATOM = (((floor(stof(lon) / 100)) + (stof(lon.substr(3, 8)) / 60)) * x_million) * (-1);
            } else {
              LONGITUDE_DD_ATOM = default_value_lon;
            }

            int year = stoi(yearSub) + 2000, month = stoi(monthSub), day = stoi(daySub), hour = stoi(timeHrSub), min = stoi(timeMinSub), sec = stoi(timeSecSub);

            printf("AGPS dbg: y = %d, m = %d, d = %d, T>%d:%d:%d\n", year, month, day, hour, min, sec);

            /* now modify the timeinfo to the given date: */
            timeinfo->tm_year = year - 1900;
            timeinfo->tm_mon = month - 1;  // months since January - [0,11]
            timeinfo->tm_mday = day;       // day of the month - [1,31]
            timeinfo->tm_hour = hour + 1;  // hours since midnight - [0,23]
            timeinfo->tm_min = min;        // minutes after the hour - [0,59]
            timeinfo->tm_sec = sec;        // seconds after the minute - [0,59]

            if (date == "0") {
              UNIX_TIME_ATOM = UNIX_TIME_ATOM + 1;
            } else {
              UNIX_TIME_ATOM = (int)mktime(timeinfo);
            }

            SPEED_ATOM = (stof(speed) * 0.514) * x_thousand;
            COG_ATOM = stof(cog) * x_hundred;

            if (status == "V") {
              GPS_STATUS_ATOM = 0;
            } else if (status == "A") {
              GPS_STATUS_ATOM = 1;
            }

          } catch (std::exception err) {
          };
        }

        if (Message_protocal == format2) {
          printf("AGPS: raw input = [%s\n", inputString.c_str());
          fflush(stdout);

          // Split the data using a comma as the delimiter
          std::stringstream ss(inputString);
          std::string token;
          std::vector<std::string> tokens;

          while (getline(ss, token, ',')) {
            if (token.size() < 64) {
              tokens.push_back(token);
            }
          }
          try {
            // clang-format off
          // @formatter:off
          // Store the values in separate variables
          mid2          = tokens.size() <= 0  ? "0" : tokens[0];
          time2         = tokens.size() <= 1  ? "0" : tokens[1];
          lat2          = tokens.size() <= 2  ? "0" : tokens[2];
          nsIndicator2  = tokens.size() <= 3  ? "0" : tokens[3];
          lon2          = tokens.size() <= 4  ? "0" : tokens[4];
          ewIndicator2  = tokens.size() <= 5  ? "0" : tokens[5];
          positionFix   = tokens.size() <= 6  ? "0" : tokens[6];
          satUsed       = tokens.size() <= 7  ? "0" : tokens[7];
          hdop          = tokens.size() <= 8  ? "0" : tokens[8];
          altitudeMSL   = tokens.size() <= 9  ? std::to_string((float)default_value_alt / (float)x_hundred) : tokens[9];
          altitudeUnit  = tokens.size() <= 10 ? "0" : tokens[10];
          geoidSep      = tokens.size() <= 11 ? "0" : tokens[11];
          geoidSepUnit  = tokens.size() <= 12 ? "0" : tokens[12];
          emptyDGPS     = tokens.size() <= 13 ? "0" : tokens[13];
          modeChecksum2 = tokens.size() <= 14 ? "0" : tokens[14];

            // clang-format on
            // @formatter:on
            if (isNumber(altitudeMSL)) {
              ALTITUDE_MSL_ATOM = stof(altitudeMSL) * x_hundred;
            }
            if (isNumber(satUsed)) {
              SATELLITE_USED_ATOM = stoi(satUsed);
            }
            if (isNumber(hdop)) {
              HDOP_ATOM = stof(hdop) * x_hundred;
            }
            if (isNumber(positionFix)) {
              GPS_FIXED_STATUS_ATOM = stoi(positionFix);
            }
          } catch (std::exception err) {
          };
        }
        inputString = "";
        string_complete = false;
      }
    }
    memset(read_buf, 0, 255);
  }

  if (inChar == "\n") {
    string_complete = true;

    if (string_complete) {
      std::string Message_protocal = inputString.substr(0, 6);
      if (Message_protocal == format1) {
        // Split the data using a comma as the delimiter
        std::stringstream ss(inputString);
        std::string token;
        std::vector<std::string> tokens;

        while (getline(ss, token, ',')) {
          tokens.push_back(token);
        }

        // Store the values in separate variables
        std::string mid1 = tokens[0];
        std::string time = tokens[1];
        if (time == "") {
          time = "0";
        }
        std::string status = tokens[2];
        std::string lat = tokens[3];
        if (lat == "") {
          lat = "99999999";
        }
        std::string nsIndicator = tokens[4];
        if (nsIndicator == "") {
          nsIndicator = "0";
        }
        std::string lon = tokens[5];
        if (lon == "") {
          lon = "999999999";
        }
        std::string ewIndicator = tokens[6];
        if (ewIndicator == "") {
          ewIndicator = "0";
        }
        std::string speed = tokens[7];
        if (speed == "") {
          speed = "0";
        }
        std::string cog = tokens[8];
        if (cog == "") {
          cog = "444.44";
        }
        std::string date = tokens[9];
        if (date == "") {
          date = "0";
        }
        std::string empty1 = tokens[10];
        std::string empty2 = tokens[11];
        std::string modeChecksum = tokens[12];
        if (modeChecksum == "") {
          modeChecksum = "0";
        }
        std::string daySub = "0";
        std::string monthSub = "0";
        std::string yearSub = "0";
        if (date != "0") {
          daySub = date.substr(0, 2).c_str();
          monthSub = date.substr(2, 2).c_str();
          yearSub = date.substr(4, 2).c_str();
        }

        std::string timeHrSub = "0";
        std::string timeMinSub = "0";
        std::string timeSecSub = "0";
        if (time != "0") {
          timeHrSub = time.substr(0, 2).c_str();
          timeMinSub = time.substr(2, 2).c_str();
          timeSecSub = time.substr(4, 2).c_str();
        }

        if (nsIndicator == "N" && lat != "99999999") {
          LATITUDE_DD_ATOM = ((floor(stof(lat) / 100)) + (stof(lat.substr(2, 8)) / 60)) * x_million;
        } else if (nsIndicator == "S" && lat != "99999999") {
          LATITUDE_DD_ATOM = (((floor(stof(lat) / 100)) + (stof(lat.substr(2, 8)) / 60)) * x_million) * (-1);
        } else {
          LATITUDE_DD_ATOM = stoi(lat);
        }

        if (ewIndicator == "E" && lon != "999999999") {
          LONGITUDE_DD_ATOM = ((floor(stof(lon) / 100)) + (stof(lon.substr(3, 8)) / 60)) * x_million;
        } else if (ewIndicator == "W" && lon != "999999999") {
          LONGITUDE_DD_ATOM = (((floor(stof(lon) / 100)) + (stof(lon.substr(3, 8)) / 60)) * x_million) * (-1);
        } else {
          LONGITUDE_DD_ATOM = stoi(lon);
        }

        int year = stoi(yearSub) + 2000, month = stoi(monthSub), day = stoi(daySub), hour = stoi(timeHrSub), min = stoi(timeMinSub), sec = stoi(timeSecSub);
        /* now modify the timeinfo to the given date: */
        timeinfo->tm_year = year - 1900;
        timeinfo->tm_mon = month - 1;  // months since January - [0,11]
        timeinfo->tm_mday = day;       // day of the month - [1,31]
        timeinfo->tm_hour = hour;      // hours since midnight - [0,23]
        timeinfo->tm_min = min;        // minutes after the hour - [0,59]
        timeinfo->tm_sec = sec;        // seconds after the minute - [0,59]
        timeinfo->tm_isdst = -1;       // Daylight saving time not set

        if (date == "0") {
          UNIX_TIME_ATOM = 0;
        } else {
          UNIX_TIME_ATOM = (int)mktime(timeinfo);
        }

        SPEED_ATOM = (stof(speed) * 0.514) * x_thousand;
        COG_ATOM = stof(cog) * x_hundred;

        if (status == "V") {
          GPS_STATUS_ATOM = 0;
        } else if (status == "A") {
          GPS_STATUS_ATOM = 1;
        }
      }

      if (Message_protocal == format2) {
        // Split the data using a comma as the delimiter
        std::stringstream ss(inputString);
        std::string token;
        std::vector<std::string> tokens;

        while (getline(ss, token, ',')) {
          tokens.push_back(token);
        }

        // Store the values in separate variables
        std::string mid2 = tokens[0];
        std::string time2 = tokens[1];
        if (time2 == "") {
          time2 = "0";
        }
        std::string lat2 = tokens[2];
        if (lat2 == "") {
          lat2 = "0";
        }
        std::string nsIndicator2 = tokens[3];
        if (nsIndicator2 == "") {
          nsIndicator2 = "0";
        }
        std::string lon2 = tokens[4];
        if (lon2 == "") {
          lon2 = "0";
        }
        std::string ewIndicator2 = tokens[5];
        if (ewIndicator2 == "") {
          ewIndicator2 = "0";
        }
        std::string positionFix = tokens[6];
        if (positionFix == "") {
          positionFix = "0";
        }
        std::string satUsed = tokens[7];
        if (satUsed == "") {
          satUsed = "0";
        }
        std::string hdop = tokens[8];
        if (hdop == "") {
          hdop = "0";
        }
        std::string altitudeMSL = tokens[9];
        if (altitudeMSL == "") {
          altitudeMSL = "9999.99";
        }
        std::string altitudeUnit = tokens[10];
        std::string geoidSep = tokens[11];
        if (geoidSep == "") {
          geoidSep = "0";
        }
        std::string geoidSepUnit = tokens[12];
        std::string emptyDGPS = tokens[13];
        std::string modeChecksum2 = tokens[14];
        if (modeChecksum2 == "") {
          modeChecksum2 = "0";
        }

        ALTITUDE_MSL_ATOM = stof(altitudeMSL) * x_hundred;
        SATELLITE_USED_ATOM = stoi(satUsed);
        HDOP_ATOM = stof(hdop) * x_hundred;
        GPS_FIXED_STATUS_ATOM = stoi(positionFix);
      }
      inputString = "";
      string_complete = false;
    }
  }
  memset(read_buf, 0, 255);
  std::cout << "thread GPS Operate closed" << std::endl << std::flush;
  return 0;
}

int Status_check() {
  while (thread_status == 1) {
    if (GPS_UART_STATUS_ATOM == 0) {
      GPS_CURRENT_STATUS_ATOM = 0;
    } else if (GPS_WIRE_CHECK == 0) {
      GPS_CURRENT_STATUS_ATOM = 0;
    } else {
      if (GPS_STATUS_ATOM == 0 && GPS_FIXED_STATUS_ATOM != 1 && UNIX_TIME_ATOM == 0) {
        GPS_CURRENT_STATUS_ATOM = 1;
      } else {
        if (GPS_STATUS_ATOM == 0 && GPS_FIXED_STATUS_ATOM != 1 && UNIX_TIME_ATOM > 0) {
          GPS_CURRENT_STATUS_ATOM = 2;
        } else if (GPS_STATUS_ATOM == 1 && GPS_FIXED_STATUS_ATOM != 1 && UNIX_TIME_ATOM > 0) {
          GPS_CURRENT_STATUS_ATOM = 2;
        } else {
          GPS_CURRENT_STATUS_ATOM = 3;
        }
      }
    }
    std::this_thread::sleep_for(std::chrono::milliseconds(1000));
  }
  std::cout << "thread Status Check closed" << std::endl << std::flush;
  return 0;
}

int clear_value_to_default() {
  LATITUDE_DD_ATOM = default_value_lat;
  LONGITUDE_DD_ATOM = default_value_lon;
  UNIX_TIME_ATOM = default_value_unix_time;
  SPEED_ATOM = default_value_speed;
  COG_ATOM = default_value_cog;
  ALTITUDE_MSL_ATOM = default_value_sat_used;
  SATELLITE_USED_ATOM = default_value_sat_used;
  HDOP_ATOM = default_value_hdop;
  return 0;
}

// GPS TC_1
int GPS_TC_1(const TTCInternal* ttc, const Services* services) {
  services->Log->log(LogLevel::DEBUG, "Working GPS_TC_1");
  auto pool = new Datapool("/302.2");
  TTCInternal _ttc = *ttc;
  _ttc.ctrlType = CtrlType::TC_ret;
  if (thread_status != 1) {
    thread_status = 1;
    _ttc.value = 0;
    GPS_uartSetup();
    services->Log->log(LogLevel::DEBUG, "GPS_TC_1 UART Setup...");
    services->MQ_Return->Send(_ttc);
    services->Log->log(LogLevel::INFO, "TC 1 return value: " + fmt::format("{}", _ttc.value));
  } else {
    _ttc.value = 1;  // repeat request
    services->MQ_Return->Send(_ttc);
    services->Log->log(LogLevel::WARNING, "Warning GPS_TC_1 GPS already sampling : Reject\n");
    services->Log->log(LogLevel::INFO, "TC 1 return value: " + fmt::format("{}", _ttc.value));
    return 1;
  }
  services->Log->log(LogLevel::DEBUG, "GPS_TC_1 Start Sampling...");
  std::thread GPS_thread1(GPS_Operate);
  std::thread GPS_thread2(Status_check);
  std::thread GPS_thread3([=]() {
    services->Log->log(LogLevel::DEBUG, "GPS data pooling in progress");
    while (thread_status == 1) {
      pool->Set(1, GPS_CURRENT_STATUS_ATOM);
      pool->Set(2, UNIX_TIME_ATOM);
      pool->Set(3, LATITUDE_DD_ATOM);
      pool->Set(4, LONGITUDE_DD_ATOM);
      pool->Set(5, ALTITUDE_MSL_ATOM);
      pool->Set(6, SPEED_ATOM);
      pool->Set(7, COG_ATOM);
      pool->Set(8, SATELLITE_USED_ATOM);
      pool->Set(9, GPS_SOFTWARE_VERSION);
      pool->Set(10, HDOP_ATOM);

      std::this_thread::sleep_for(std::chrono::seconds(1));
    }
    services->Log->log(LogLevel::DEBUG, "thread GPS Data pooling closed");
    std::cout << "thread GPS Data pooling closed" << std::endl << std::flush;
    return 0;
  });
  /*std::thread GPS_thread4([=]() {
    services->Log->log(LogLevel::DEBUG, "GPS data LOG in progress");
    while (thread_status == 1) {
      services->Log->log(LogLevel::INFO, "GPS STATUS : " + fmt::format("{}", GPS_CURRENT_STATUS_ATOM));
      services->Log->log(LogLevel::INFO, "GPS UNIX TIME : " + fmt::format("{}", UNIX_TIME_ATOM));
      services->Log->log(LogLevel::INFO, "GPS LATITUDE DD : " + fmt::format("{}", LATITUDE_DD_ATOM));
      services->Log->log(LogLevel::INFO, "GPS LONGITUDE DD : " + fmt::format("{}", LONGITUDE_DD_ATOM));
      services->Log->log(LogLevel::INFO, "GPS ALTITUDE MSL : " + fmt::format("{}", ALTITUDE_MSL_ATOM));
      services->Log->log(LogLevel::INFO, "GPS SPEED : " + fmt::format("{}", SPEED_ATOM));
      services->Log->log(LogLevel::INFO, "GPS COG : " + fmt::format("{}", COG_ATOM));
      services->Log->log(LogLevel::INFO, "GPS SATELLITE USED : " + fmt::format("{}", SATELLITE_USED_ATOM));
      services->Log->log(LogLevel::INFO, "GPS SOFTWARE VERSION : " + fmt::format("{}", GPS_SOFTWARE_VERSION));
      services->Log->log(LogLevel::INFO, "GPS HDOP : " + fmt::format("{}", HDOP_ATOM));
      services->Log->log(LogLevel::INFO, "---------END----------\n");
      std::this_thread::sleep_for(std::chrono::seconds(5));
    }
    services->Log->log(LogLevel::DEBUG, "thread GPS Data LOG closed");
    return 0;
  });*/
  GPS_thread1.detach();
  GPS_thread2.detach();
  GPS_thread3.detach();
 // GPS_thread4.detach();
  return 0;
}

// GPS TC_2
int GPS_TC_2(const TTCInternal* ttc, const Services* services) {
  services->Log->log(LogLevel::DEBUG, "working GPS_TC_2");
  TTCInternal _ttc = *ttc;
  _ttc.ctrlType = CtrlType::TC_ret;

  if (thread_status != 0) {
    thread_status = 0;
    _ttc.value = 0;
    clear_value_to_default();
    services->Log->log(LogLevel::DEBUG, "GPS_TC_2 clear to default value");
    services->Log->log(LogLevel::DEBUG, "GPS_TC_2 stop sampling");
    services->MQ_Return->Send(_ttc);
  } else {
    _ttc.value = 1;  // repeat request
    services->Log->log(LogLevel::WARNING, "GPS_TC_2 repeat request : Reject");
    services->MQ_Return->Send(_ttc);
    return 1;
  }
  services->Log->log(LogLevel::DEBUG, "GPS_TC_2 END");
  return 0;
}

int GPS_TM_1(const TTCInternal* ttc,
             const Services* services) {  // TM GPS Status -> (0 = UART failed / 1 = Not Fixed / 2 = Time Only / 3 = fixed / 4 = Not Sampling)
  services->Log->log(LogLevel::INFO, "TM 1 Start");
  TTCInternal _ttc = *ttc;
  _ttc.ctrlType = CtrlType::TM_ret;
  if (thread_status == 1) {
    _ttc.value = GPS_CURRENT_STATUS_ATOM;
  } else {
    _ttc.value = 4;
  }
  services->MQ_Return->Send(_ttc);
  services->Log->log(LogLevel::INFO, "TM_1 return value: " + fmt::format("{}", _ttc.value));
  services->Log->log(LogLevel::INFO, "TM 1 End\n");
  return 0;
}

int GPS_TM_2(const TTCInternal* ttc, const Services* services) {  // TM GPS Unix Time
  services->Log->log(LogLevel::INFO, "TM 2 Start");
  TTCInternal _ttc = *ttc;
  _ttc.ctrlType = CtrlType::TM_ret;
  _ttc.value = UNIX_TIME_ATOM;
  services->MQ_Return->Send(_ttc);
  services->Log->log(LogLevel::INFO, "TM 2 return value: " + fmt::format("{}", _ttc.value));
  services->Log->log(LogLevel::INFO, "TM 2 End\n");
  return 0;
}

int GPS_TM_3(const TTCInternal* ttc, const Services* services) {  // TM GPS Latitude
  services->Log->log(LogLevel::INFO, "TM 3 Start");
  TTCInternal _ttc = *ttc;
  _ttc.ctrlType = CtrlType::TM_ret;
  _ttc.value = LATITUDE_DD_ATOM;
  services->MQ_Return->Send(_ttc);
  services->Log->log(LogLevel::INFO, "TM 3 return value: " + fmt::format("{}", _ttc.value));
  services->Log->log(LogLevel::INFO, "TM 3 End\n");
  return 0;
}

int GPS_TM_4(const TTCInternal* ttc, const Services* services) {  // TM GPS Longitude
  services->Log->log(LogLevel::INFO, "TM 4 Start");
  TTCInternal _ttc = *ttc;
  _ttc.ctrlType = CtrlType::TM_ret;
  _ttc.value = LONGITUDE_DD_ATOM;
  services->MQ_Return->Send(_ttc);
  services->Log->log(LogLevel::INFO, "TM 4 return value: " + fmt::format("{}", _ttc.value));
  services->Log->log(LogLevel::INFO, "TM 4 End\n");
  return 0;
}

int GPS_TM_5(const TTCInternal* ttc, const Services* services) {  // TM GPS Altitude (Mean Sea Level)
  services->Log->log(LogLevel::INFO, "TM 5 Start");
  TTCInternal _ttc = *ttc;
  _ttc.ctrlType = CtrlType::TM_ret;
  _ttc.value = ALTITUDE_MSL_ATOM;
  services->MQ_Return->Send(_ttc);
  services->Log->log(LogLevel::INFO, "TM 5 return value: " + fmt::format("{}", _ttc.value));
  services->Log->log(LogLevel::INFO, "TM 5 End\n");
  return 0;
}

int GPS_TM_6(const TTCInternal* ttc, const Services* services) {  // TM GPS Speed (unit : m/s)
  services->Log->log(LogLevel::INFO, "TM 6 Start");
  TTCInternal _ttc = *ttc;
  _ttc.ctrlType = CtrlType::TM_ret;
  _ttc.value = SPEED_ATOM;
  services->MQ_Return->Send(_ttc);
  services->Log->log(LogLevel::INFO, "TM 6 return value: " + fmt::format("{}", _ttc.value));
  services->Log->log(LogLevel::INFO, "TM 6 End\n");
  return 0;
}

int GPS_TM_7(const TTCInternal* ttc, const Services* services) {  // TM GPS COG (course over ground)
  services->Log->log(LogLevel::INFO, "TM 7 Start");
  TTCInternal _ttc = *ttc;
  _ttc.ctrlType = CtrlType::TM_ret;
  _ttc.value = COG_ATOM;
  services->MQ_Return->Send(_ttc);
  services->Log->log(LogLevel::INFO, "TM 7 return value: " + fmt::format("{}", _ttc.value));
  services->Log->log(LogLevel::INFO, "TM 7 End\n");
  return 0;
}

int GPS_TM_8(const TTCInternal* ttc, const Services* services) {  // TM GPS Satellite number of used
  services->Log->log(LogLevel::INFO, "TM 8 Start");
  TTCInternal _ttc = *ttc;
  _ttc.ctrlType = CtrlType::TM_ret;
  _ttc.value = SATELLITE_USED_ATOM;
  services->MQ_Return->Send(_ttc);
  services->Log->log(LogLevel::INFO, "TM 8 return value: " + fmt::format("{}", _ttc.value));
  services->Log->log(LogLevel::INFO, "TM 8 End\n");
  return 0;
}

int GPS_TM_9(const TTCInternal* ttc, const Services* services) {  // TM GPS Software Version
  services->Log->log(LogLevel::INFO, "TM 9 Start");
  TTCInternal _ttc = *ttc;
  _ttc.ctrlType = CtrlType::TM_ret;
  _ttc.value = GPS_SOFTWARE_VERSION;
  services->MQ_Return->Send(_ttc);
  services->Log->log(LogLevel::INFO, "TM 9 return value: " + fmt::format("{}", _ttc.value));
  services->Log->log(LogLevel::INFO, "TM 9 End\n");
  return 0;
}

int GPS_TM_10(const TTCInternal* ttc, const Services* services) {  // TM GPS HDOP (Horizontal Dilution of Precision)
  services->Log->log(LogLevel::INFO, "TM 10 Start");
  TTCInternal _ttc = *ttc;
  _ttc.ctrlType = CtrlType::TM_ret;
  _ttc.value = HDOP_ATOM;
  services->MQ_Return->Send(_ttc);
  services->Log->log(LogLevel::INFO, "TM 10 return value: " + fmt::format("{}", _ttc.value));
  services->Log->log(LogLevel::INFO, "TM 10 End\n");
  return 0;
}

int main(int argc, char* argv[]) {
  auto fsw_pool = new Datapool("/303");
  auto logger = new Logger();
  logger->setLogLevel(fsw_pool->Get(5));
  logger->setModuleID(3022);
  logger->setLogMQName("/log.sub");
  logger->setManualMQService();

  Datapool* pool = new Datapool("/302.2");
  CMqueue* mq_request = new CMqueue("/302.2");
  CMqueue* mq_return = new CMqueue("/realtime");
  CMqueue* mq_log = new CMqueue("/log.sub");

  if (mq_return->OpenWrite() == -1) {
    logger->log(LogLevel::ERROR, "Failed to open message queue");
    return EXIT_FAILURE;
  } else {
    logger->log(LogLevel::INFO, "connected MQ_Return");
  }

  if (mq_request->OpenRead() == -1) {
    logger->log(LogLevel::ERROR, "Failed to open message queue");
    return EXIT_FAILURE;
  } else {
    logger->log(LogLevel::INFO, "connected MQ_Request");
  }

  if (mq_log->OpenWrite() == -1) {
    logger->log(LogLevel::ERROR, "Failed to open message queue");
    return EXIT_FAILURE;
  } else {
    logger->log(LogLevel::INFO, "connected MQ_Logger");
  }

  // ======================= Start subsystem code ========================================
  std::unordered_map<int, std::function<void(TTCInternal*, Services*)>> tc_actions;
  std::unordered_map<int, std::function<void(TTCInternal*, Services*)>> tm_actions;

  // tc_actions[<<commandID>>] = function()
  tc_actions[1] = GPS_TC_1;
  tc_actions[2] = GPS_TC_2;

  // tm_actions[<<commandID>>] = function()
  tm_actions[1] = GPS_TM_1;
  tm_actions[2] = GPS_TM_2;
  tm_actions[3] = GPS_TM_3;
  tm_actions[4] = GPS_TM_4;
  tm_actions[5] = GPS_TM_5;
  tm_actions[6] = GPS_TM_6;
  tm_actions[7] = GPS_TM_7;
  tm_actions[8] = GPS_TM_8;
  tm_actions[9] = GPS_TM_9;
  tm_actions[10] = GPS_TM_10;

  // ===============================================================
  TTCInternal message;
  unsigned int priority;
  Services* services = new Services;
  services->MQ_Return = mq_return;
  services->Log = logger;
  services->Pool = pool;

  while (true) {
    ssize_t bytes_read = mq_receive(mq_request->mq_dest, reinterpret_cast<char*>(&message), 64, NULL);
    if (bytes_read == -1) {
      perror("mq_receive");
    } else {
      auto msg = &message;

      logger->log(fmt::format("{}", message.requestTime));
      switch (msg->ctrlType) {
        case CtrlType::TC_req:
          if (tc_actions.contains((int)msg->commandID)) {
            (tc_actions)[msg->commandID](msg, services);
          }
          break;
        case CtrlType::TM_req:
          if (tm_actions.contains((int)msg->commandID)) {
            (tm_actions)[msg->commandID](msg, services);
          }
          break;
      }
    }
  }
  return 0;
}
