/*
████████╗██╗  ██╗███████╗ ██████╗ ███████╗      ██████╗  █████╗
╚══██╔══╝██║  ██║██╔════╝██╔═══██╗██╔════╝      ╚════██╗██╔══██╗
   ██║   ███████║█████╗  ██║   ██║███████╗█████╗ █████╔╝███████║
   ██║   ██╔══██║██╔══╝  ██║   ██║╚════██║╚════╝██╔═══╝ ██╔══██║
   ██║   ██║  ██║███████╗╚██████╔╝███████║      ███████╗██║  ██║
   ╚═╝   ╚═╝  ╚═╝╚══════╝ ╚═════╝ ╚══════╝      ╚══════╝╚═╝  ╚═╝

 File: AGNC.cpp
 Author: Jirayu Peetakul
===============================================================
 [description here]

 Developer: Aroonsak Bootchai
 Developer: Jirayu Peetakul (last editor)
 Project: SchoolSAT
 Date: 2023-OCT-05
 Version: 103
===============================================================
*/

#include <dirent.h>
#include <fcntl.h>
#include <fmt/format.h>
#include <mqueue.h>
#include <poll.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <sys/mman.h>
#include <sys/signalfd.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cmath>
#include <ctime>
#include <filesystem>
#include <fstream>
#include <functional>
#include <iostream>
#include <map>
#include <opencv2/core.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/opencv.hpp>
#include <stdexcept>
#include <string>
#include <thread>
#include <typeinfo>
#include <vector>

#include "../include/CCommand.hpp"
#include "../include/CConfig.hpp"
#include "../include/CDataPool.hpp"
#include "../include/CExecutor.hpp"
#include "../include/CLog.hpp"
#include "../include/CMqueue.hpp"
#include "../include/ITTC.hpp"
#include "fmt/core.h"
#include "lib/LibCamera.h"

#define MODE_SINGLE 0
#define MODE_STRIP 2
#define MODE_VIDEO 1
#define EXPIREDTIME 1400                     // Expired time in sec
#define FRAME_WIDTH 1920                     // horizontal
#define FRAME_HEIGHT 1080                    // vertical
#define OUTPUTPATH1 "/opt/schoolsat/OUTPUT"  // output path
#define LOGPATH1 "/opt/schoolsat/OUTPUT"     // Log camera path
#define OPPATH1 "/opt/schoolsat/OUTPUT"
#define LOG_FILE_NAME1 "AP306_camera_log"
#define OP_FILE_NAME1 "AP306_camera_op"
#define Raspi1 "RaspberryPi"  // NONRaspberryPi or RaspberryPi
#define InitialiseDelay 450   // ms unit

#define CAM_IDLE 0
#define CAM_BUSY 1
#define CAM_ERROR 2
#define IMAGING_IDLE 0
#define IMAGING_BUSY 1
#define IMAGING_ERROR 2
#define WRITEBACK_READY 0
#define WRITEBACK_NOT_REDAY 1
#define WRITEBACK_ERROR 2

using namespace cv;
using namespace std;
using namespace std::chrono;
using namespace std::placeholders;
using std::chrono::duration_cast;
using std::chrono::milliseconds;  // for Counter function
using std::chrono::system_clock;

namespace fs = std::filesystem;

//====global Variable=============
string OUTPUTPATH = OUTPUTPATH1;  // output path
string LOGPATH = LOGPATH1;        // Log camera path
string LOG_FILE_NAME = LOG_FILE_NAME1;
string OPPATH = OPPATH1;
string OP_FILE_NAME = OP_FILE_NAME1;
string Raspi = Raspi1;  // NONRaspberryPi or RaspberryP
string ErrorFile = "NULL";

std::ofstream writerLOG;
std::ofstream writerMD;
std::atomic<bool> ATOMcamera_thread = false;
std::atomic<bool> ATOMzip_status = false;
std::atomic<uint8_t> camera_mode = 0;
std::atomic<uint8_t> camera_status = 0;
std::atomic<bool> zip_thread = false;

std::atomic<time_t> start_time = time(0);
std::atomic<float> lens_position = 100;
std::atomic<float> focus_step = 50;

std::atomic<uint8_t> atom_camera_status = 0;
std::atomic<uint8_t> atom_imaging_status = 0;
std::atomic<uint8_t> atom_writeback_status = 0;
uint16_t softwareVersion = 103;

uint32_t width = FRAME_WIDTH;
uint32_t height = FRAME_HEIGHT;
uint32_t stride;

// change to atomic variable
/* Capture configuration */
uint32_t imgNum = 0;
uint32_t intervalTime = 0;
uint32_t integrationTime = 0;
uint32_t frame_counter = 0;

LibCamera cam;
LibcameraOutData frameData;

struct CTCparams {
  /*==intermal MSG struct decalation==*/
  uint8_t imageNum;
  uint32_t intervalTime;
  uint8_t offSet;
  uint8_t timeOffset;
  uint8_t TCcheck;
  uint8_t Mode;
  // 000: MODE_SINGLE_SHOT
};

struct filestate {
  /*==Chack old file struct for TM303==*/
  uint8_t oldfileState = 1;
  uint8_t nofileState = 1;
  uint8_t unzipfileState = 0;
};

struct TCparams {
  /*==Chack exprosure time calculation==*/
  int maxProsure = 330;  // in ms uint
  int minProsure = 1;    // in ms uint
  uint16_t ExprosureTime;
};

std::atomic<uint8_t> atom_thread_status = 0;

class TCcommand {
 public:
  std::string createOutput(const std::string& fullPath, const std::string& module) {
    time_t now = time(0);
    std::string folder_name = fmt::format("{0}_{1}", now, module);  // unixtime_moduleName
    std::string path = fmt::format("{0}{1}", fullPath, folder_name);
    // eg. fullPath = /3PL/output/PAYLOAD_OUT
    if (std::filesystem::is_directory(fullPath)) {
      std::system(fmt::format("mkdir {0}", path).c_str());
    }
    return path;
  };

  void Counter(uint32_t intervalTime) {
    /*==a counter for camera operation==*/
    int Count = intervalTime / 1000;
    int i = 0;
    std::cout << "Interval Time: " << intervalTime << "| Count: " << Count << std::endl << std::flush;
    if (Count < 1) {
      this_thread::sleep_for(chrono::milliseconds(intervalTime));
    } else {
      do {
        sleep(1);
        i = i + 1;
      } while (i < Count);
    }
  }

  string unixTime() {
    /*==Get unixtime as string output function==*/
    string utime;
    time_t times = time(0);
    utime = to_string(times);
    return (utime);
  }

  void rmEXFILE(string OUTPUTPATH) {
    /*==Remove Expired camera output before starting the new operation==*/
    DIR* dir;
    struct dirent* ent;
    const char* path = OUTPUTPATH.c_str();
    string dirname, pathfile;
    uint8_t istr;
    uint16_t opertime = EXPIREDTIME;  // can be updated
    if ((dir = opendir(path)) != NULL) {
      while ((ent = readdir(dir)) != NULL) {
        dirname = ent->d_name;
        if (dirname.size() > 5) {
          struct stat t_stat;
          pathfile = OUTPUTPATH + "/" + dirname;
          const char* files = (pathfile).c_str();
          stat(files, &t_stat);
          struct tm* timeinfo = localtime(&t_stat.st_ctime);
          if (stoi(unixTime()) - mktime(timeinfo) > opertime) {
            std::system(fmt::format("cd {0};rm -r {1}", OUTPUTPATH, dirname).c_str());
          }
        }
      }
    }
  }

  void camera_stop() {
    /*==Stop TC301operation thread (TC302)==*/
    ATOMcamera_thread = false;  // force stop camera threadcamera_thread_1 = false; // force stop camera thread
    return;
  }

  string createDIR(string OUTPUTPATH) {
    /*==Create output folder(Now use from the framework code)==*/
    string utime = unixTime();
    string folder_name = utime + "_WP306CAMERA";
    string output = OUTPUTPATH + folder_name;
    const char* coutput = output.c_str();
    mkdir(coutput, 0);
    return (output);
  }

  int cameraInit() {
    int ret = cam.initCamera();
    cam.stopCamera();
    cam.closeCamera();
    return ret;
  }

  void cameraOper(TCparams TCpars, const Services* services, uint32_t imgNum, uint32_t intervalTime, string utime, string CAMPATH, string filename, uint8_t mode) {
    bool flag;
    int imageCounter = 0;
    // uint8_t i = 0;

    int ret = cam.initCamera();

    services->Pool->Set(1, CAM_BUSY);
    atom_camera_status = CAM_BUSY;

    cam.configureStill(width, height, formats::RGB888, 1, 0);
    ControlList controls_;
    int64_t frame_time = 1000000 / 10;
    // Set frame rate
    controls_.set(controls::FrameDurationLimits, libcamera::Span<const int64_t, 2>({frame_time, frame_time}));
    // Adjust the brightness of the output images, in the range -1.0 to 1.0
    controls_.set(controls::Brightness, 0.0);
    // Adjust the contrast of the output image, where 1.0 = normal contrast
    controls_.set(controls::Contrast, 1.0);
    // Set the exposure time
    controls_.set(controls::ExposureTime, integrationTime);
    cam.set(controls_);

    writerMD.open(fmt::format("{0}/{1}.md", CAMPATH, filename), std::ios_base::app);
    std::vector<int> compression_params;
    compression_params.push_back(1);  // CV_IMWRITE_JPEG_QUALITY = 1
    compression_params.push_back(100);
    this_thread::sleep_for(chrono::milliseconds(InitialiseDelay));  // wait for FM camera to find out
    cv::Mat imageErr[imgNum];
    try {
      if (mode == MODE_STRIP) {
        std::cout << "Camera started in strip mode. \n";
        // Stip mode capture
        // cam.startCamera();
        // cam.VideoStream(&width, &height, &stride);
        do {
          cam.startCamera();
          cam.VideoStream(&width, &height, &stride);
          flag = cam.readFrame(&frameData);
          if (!flag) continue;
          services->Pool->Set(2, IMAGING_BUSY);
          atom_imaging_status = IMAGING_BUSY;

          Mat image(height, width, CV_8UC3, frameData.imageData, stride);
          cv::imwrite(fmt::format("{0}/{1}_{2}-[{3}].jpg", CAMPATH, time(0), "STRIP_IMAGE_NUMBER", imageCounter), image, compression_params);
          writerMD << fmt::format("{0}_{1} {2}\n", time(0), "IMAGE NUMBER:", imageCounter);
          imageCounter++;
          if (imageCounter < imgNum) {
            Counter(intervalTime);
          }
          cam.returnFrameBuffer(frameData);
        } while (imageCounter < imgNum);  // camera thread will work only == true

        /* Reset all global variable to zero and waiting for the next setup */
        imgNum = 0;
        intervalTime = 0;
        integrationTime = 0;
        frame_counter = 0;

        cam.stopCamera();
        std::cout << "Camera in strip mode stopped. \n";
        cam.closeCamera();
        std::cout << "Camera in strip mode closed. \n";

        services->Pool->Set(2, IMAGING_IDLE);
        atom_imaging_status = IMAGING_IDLE;
      }

      else if (mode == MODE_SINGLE) {
        std::cout << "Camera started in single mode. \n";
        // Single Shot capture
        cam.startCamera();
        cam.VideoStream(&width, &height, &stride);
        do {
          flag = cam.readFrame(&frameData);
          if (!flag) continue;
          services->Pool->Set(2, IMAGING_BUSY);
          atom_imaging_status = IMAGING_BUSY;

          Mat image(height, width, CV_8UC3, frameData.imageData, stride);
          cv::imwrite(fmt::format("{0}/{1}_{2}-[{3}].jpg", CAMPATH, time(0), "SINGLE_IMAGE_NUMBER", imageCounter), image, compression_params);
          writerMD << fmt::format("{0}_{1} {2}\n", time(0), "IMAGE NUMBER:", imageCounter);
          imageCounter++;
          cam.returnFrameBuffer(frameData);
        } while (imageCounter < imgNum);  // camera thread will work only == true

        /* Reset all global variable to zero and waiting for the next setup */
        imgNum = 0;
        intervalTime = 0;
        integrationTime = 0;
        frame_counter = 0;

        cam.stopCamera();
        std::cout << "Camera in single mode stopped. \n";
        cam.closeCamera();
        std::cout << "Camera in single mode closed. \n";

        services->Pool->Set(2, IMAGING_IDLE);
        atom_imaging_status = IMAGING_IDLE;
      }

      else if (mode == MODE_VIDEO) {
        std::cout << "Camera started in video mode. \n";
        Mat image(height, width, CV_8UC3);
        //--- INITIALIZE VIDEOWRITER
        VideoWriter writer;
        int codec = cv::VideoWriter::fourcc('M', 'J', 'P', 'G');  // select desired codec (must be available at runtime)
        double fps = 10.0;                                        // framerate of the created video stream
        writer.open(fmt::format("{0}/{1}_{2}-[{3}].avi", CAMPATH, time(0), "VIDEO_NUMBER", 0), codec, fps, image.size(), CV_8UC3);
        // check if we succeeded
        if (!writer.isOpened()) {
          cerr << "Could not open the output video file to write. \n";
          return;
        }
        cam.startCamera();
        cam.VideoStream(&width, &height, &stride);
        while (true) {
          flag = cam.readFrame(&frameData);
          if (!flag) continue;
          services->Pool->Set(2, IMAGING_BUSY);
          atom_imaging_status = IMAGING_BUSY;

          // encode the frame into the videofile stream
          long long stMillis = static_cast<long long>(time(0)) * 1000;
          Mat temp(height, width, CV_8UC3, frameData.imageData);
          writer.write(temp);
          cam.returnFrameBuffer(frameData);
          std::cout << frame_counter << " Mat time" << to_string((static_cast<long long>(time(0)) * 1000) - stMillis) << std::endl << std::flush;
          frame_counter++;
          // Counter(int(1000/fps));
          if (frame_counter > imgNum) {
            break;
          }
        }

        /* Reset all global variable to zero and waiting for the next setup */
        imgNum = 0;
        intervalTime = 0;
        integrationTime = 0;
        frame_counter = 0;

        cam.stopCamera();
        std::cout << "Camera in video mode stopped. \n";
        cam.closeCamera();
        std::cout << "Camera in video mode closed. \n";

        services->Pool->Set(2, IMAGING_IDLE);
        atom_imaging_status = IMAGING_IDLE;
      }

      services->Pool->Set(1, CAM_IDLE);
      atom_camera_status = CAM_IDLE;
      writerMD.close();
    } catch (exception& err) {
      services->Pool->Set(1, CAM_ERROR);
      atom_camera_status = CAM_ERROR;

      services->Pool->Set(2, IMAGING_ERROR);
      atom_imaging_status = IMAGING_ERROR;

      services->Pool->Set(3, WRITEBACK_ERROR);
      atom_writeback_status = WRITEBACK_ERROR;

      writerLOG.open(fmt::format("{0}{1}", LOGPATH, LOG_FILE_NAME), std::ios_base::app);
      writerLOG << fmt::format("{0}_CAPTURING MISSION HAS BEEN FAILED BY AN ERROR: {1}\n", time(0), err.what());
      writerLOG.close();
      writerMD.close();
    }
  }

  void SingleMode(TCparams TCpars, const Services* services, string outPath, uint32_t imgNum, uint32_t intervalTime) {
    services->Pool->Set(3, WRITEBACK_NOT_REDAY);
    atom_writeback_status = WRITEBACK_NOT_REDAY;

    /*==Single Shot mode function==*/
    uint8_t mode = MODE_SINGLE;
    string utime = unixTime();
    string camPath = OUTPUTPATH;
    std::string file = OP_FILE_NAME;

    writerMD.open(fmt::format("{0}/{1}.md", camPath, file), std::ios_base::app);
    writerMD << fmt::format("{0}_{1}\n", time(0), "SINGLE SHOT MODE IS BEING OPERATED");
    writerMD << fmt::format("{0}_{1} {2} IMAGES\n", time(0), "NUMBER OF IMAGE IS", imgNum);
    writerMD << fmt::format("{0}_{1} {2} msec\n", time(0), "INTERVALTIME IS", intervalTime);
    writerMD << fmt::format("{0}_{1} {2} msec\n", time(0), "EXPROSURE TIME IS", TCpars.ExprosureTime);
    writerMD.close();

    cameraOper(TCpars, services, imgNum, intervalTime, utime, camPath, file, mode);
    ErrorFile = camPath;

    writerMD.open(fmt::format("{0}/{1}.md", camPath, file), std::ios_base::app);
    writerMD << fmt::format("{0}_{1}\n", time(0), "SINGLE MODE MISSION IS COMPLETED");
    writerMD.close();

    services->Pool->Set(3, WRITEBACK_READY);
    atom_writeback_status = WRITEBACK_READY;
  }

  void VideoMode(TCparams TCpars, const Services* services, string outPath, uint32_t imgNum, uint32_t intervalTime) {
    services->Pool->Set(3, WRITEBACK_NOT_REDAY);
    atom_writeback_status = WRITEBACK_NOT_REDAY;

    /*==Video Mode function==*/
    uint8_t mode = MODE_VIDEO;
    string utime = unixTime();
    string camPath = OUTPUTPATH;
    std::string file = OP_FILE_NAME;

    writerMD.open(fmt::format("{0}/{1}.md", camPath, file), std::ios_base::app);
    writerMD << fmt::format("{0}_{1}\n", time(0), "VIDEO MODE IS BEING OPERATED");
    writerMD << fmt::format("{0}_{1} {2} IMAGES\n", time(0), "NUMBER OF IMAGE IS", imgNum);
    writerMD << fmt::format("{0}_{1} {2} msec\n", time(0), "INTERVALTIME IS", intervalTime);
    writerMD << fmt::format("{0}_{1} {2} msec\n", time(0), "EXPROSURE TIME IS", TCpars.ExprosureTime);
    writerMD.close();

    cameraOper(TCpars, services, imgNum, intervalTime, utime, camPath, file, mode);
    ErrorFile = camPath;

    writerMD.open(fmt::format("{0}/{1}.md", camPath, file), std::ios_base::app);
    writerMD << fmt::format("{0}_{1}\n", time(0), "VIDEO MODE MISSION IS COMPLETED");
    writerMD.close();

    services->Pool->Set(3, WRITEBACK_READY);
    atom_writeback_status = WRITEBACK_READY;
  }

  void StripMode(TCparams TCpars, const Services* services, string outPath, uint32_t imgNum, uint32_t intervalTime) {
    services->Pool->Set(3, WRITEBACK_NOT_REDAY);
    atom_writeback_status = WRITEBACK_NOT_REDAY;

    /*==Strip Mode function==*/
    uint8_t mode = MODE_STRIP;
    string utime = unixTime();
    string camPath = OUTPUTPATH;
    std::string file = OP_FILE_NAME;

    writerMD.open(fmt::format("{0}/{1}.md", camPath, file), std::ios_base::app);
    writerMD << fmt::format("{0}_{1}\n", time(0), "STRIPE MODE IS BEING OPERATED");
    writerMD << fmt::format("{0}_{1} {2} IMAGES\n", time(0), "NUMBER OF IMAGE IS", imgNum);
    writerMD << fmt::format("{0}_{1} {2} msec\n", time(0), "INTERVALTIME IS", intervalTime);
    writerMD << fmt::format("{0}_{1} {2} msec\n", time(0), "EXPROSURE TIME IS", TCpars.ExprosureTime);
    writerMD.close();

    cameraOper(TCpars, services, imgNum, intervalTime, utime, camPath, file, mode);
    ErrorFile = camPath;

    writerMD.open(fmt::format("{0}/{1}.md", camPath, file), std::ios_base::app);
    writerMD << fmt::format("{0}_{1}\n", time(0), "STRIP MODE MISSION IS COMPLETED");
    writerMD.close();

    services->Pool->Set(3, WRITEBACK_READY);
    atom_writeback_status = WRITEBACK_READY;
  }

  void CameraMode(TCparams TCpars, const Services* services, uint32_t imgNum, uint32_t intervalTime, uint8_t camMode) {
    string logPath = LOGPATH;
    std::string file = LOG_FILE_NAME;

    if (camMode == MODE_SINGLE) {
      writerLOG.open(fmt::format("{0}/{1}.log", logPath, file), std::ios_base::app);
      writerLOG << fmt::format("{0}_{1}\n", time(0), "SINGLE MODE IS IN OPERATION");
      writerLOG.close();
      SingleMode(TCpars, services, OUTPUTPATH, imgNum, intervalTime);
    } else if (camMode == MODE_VIDEO) {
      writerLOG.open(fmt::format("{0}/{1}.log", logPath, file), std::ios_base::app);
      writerLOG << fmt::format("{0}_{1}\n", time(0), "VIDEO MODE IS IN OPERATION");
      writerLOG.close();
      VideoMode(TCpars, services, OUTPUTPATH, imgNum, intervalTime);
    } else if (camMode == MODE_STRIP) {
      writerLOG.open(fmt::format("{0}/{1}.log", logPath, file), std::ios_base::app);
      writerLOG << fmt::format("{0}_{1}\n", time(0), "STRIP MODE IS IN OPERATION");
      writerLOG.close();
      StripMode(TCpars, services, OUTPUTPATH, imgNum, intervalTime);
    }
  }
};

/* Telecommand for Number of image setup*/
/* the frame rate is 30 fps which allows the minimum interval for captuering as 334 ms.
   In case of 3 minutes VDO mode, it will capture 5400 images an operation.
   A return value is aways "0" */

TCcommand camCommand;
TCparams camParam;

int CAM_TC_1(const TTCInternal* ttc, const Services* services) {
  std::cout << "Telecommand 306.1: Number of image setup \n";
  atom_thread_status = 1;
  TTCInternal _ttc = *ttc;
  //_ttc.ctrlType = CtrlType::TC_ret;
  std::cout << "TC 1 Accepted: " << std::flush;
  std::cout << _ttc.value << std::endl << std::flush;
  std::thread t1([=]() {
    try {
      // operation loop
      while (atom_thread_status == 1) {
        services->Log->log(LogLevel::INFO, "Telecommand 306.1: Processing.. \n");
        imgNum = _ttc.value;
        services->Pool->Set(4, imgNum);
        // sleep thread to prevent over perform
        // std::this_thread::sleep_for(std::chrono::milliseconds(1000));
        atom_thread_status = 0;
        services->Log->log(LogLevel::INFO, "Telecommand 306.1: End \n");
      }
    } catch (std::exception error) {
      if (error.what() == "Telecommand 306.1: Exception error \n") {
        services->Log->log(LogLevel::ERROR, "Telecommand 306.1: Exception error \n");
      }
    }
    std::cout << "Telecommand 306.1: Thread closed \n";
  });
  t1.detach();
  std::cout << "Telecommand 306.1: Thread detached \n";
  /* assign data to TTCInternal.value return */
  _ttc.value = 0;
  services->MQ_Return->Send(_ttc);
  return 0;
};

/* Interval time setup */
int CAM_TC_2(const TTCInternal* ttc, const Services* services) {
  std::cout << "Telecommand 306.1: Interval time setup \n";
  atom_thread_status = 1;
  TTCInternal _ttc = *ttc;
  //_ttc.ctrlType = CtrlType::TC_ret;
  std::cout << "TC 2 Accepted: " << std::flush;
  std::cout << _ttc.value << std::endl << std::flush;
  std::thread t1([=]() {
    try {
      // operation loop
      while (atom_thread_status == 1) {
        services->Log->log(LogLevel::INFO, "Telecommand 306.1: Processing.. \n");
        intervalTime = _ttc.value;
        services->Pool->Set(5, intervalTime);
        // sleep thread to prevent over perform
        // std::this_thread::sleep_for(std::chrono::milliseconds(1000));
        atom_thread_status = 0;
        services->Log->log(LogLevel::INFO, "Telecommand 306.1: End \n");
      }
    } catch (std::exception error) {
      if (error.what() == "Telecommand 306.1: Exception error \n") {
        services->Log->log(LogLevel::ERROR, "Telecommand 306.1: Exception error \n");
      }
    }
    std::cout << "Telecommand 306.1: Thread closed \n";
  });
  t1.detach();
  std::cout << "Telecommand 306.1: Thread detached \n";
  /* assign data to TTCInternal.value return */
  _ttc.value = 0;
  services->MQ_Return->Send(_ttc);
  return 0;
};

/* Integration time setup */
int CAM_TC_3(const TTCInternal* ttc, const Services* services) {
  std::cout << "Telecommand 306.1: Integration time setup \n";
  atom_thread_status = 1;
  TTCInternal _ttc = *ttc;
  //_ttc.ctrlType = CtrlType::TC_ret;
  std::cout << "TC 3 Accepted: " << std::flush;
  std::cout << _ttc.value << std::endl << std::flush;
  std::thread t1([=]() {
    try {
      // operation loop
      while (atom_thread_status == 1) {
        services->Log->log(LogLevel::INFO, "Telecommand 306.1: Processing.. \n");
        integrationTime = _ttc.value;
        services->Pool->Set(6, integrationTime);
        // sleep thread to prevent over perform
        // std::this_thread::sleep_for(std::chrono::milliseconds(1000));
        atom_thread_status = 0;
        services->Log->log(LogLevel::INFO, "Telecommand 306.1: End \n");
      }
    } catch (std::exception error) {
      if (error.what() == "Telecommand 306.1: Exception error \n") {
        services->Log->log(LogLevel::ERROR, "Telecommand 306.1: Exception error \n");
      }
    }
    std::cout << "Telecommand 306.1: Thread closed \n";
  });
  t1.detach();
  std::cout << "Telecommand 306.1: Thread detached \n";
  /* assign data to TTCInternal.value return */
  _ttc.value = 0;
  services->MQ_Return->Send(_ttc);
  return 0;
};

/* Image capture */
int CAM_TC_4(const TTCInternal* ttc, const Services* services) {
  std::cout << "Telecommand 306.1: Image capture \n";
  TTCInternal _ttc = *ttc;
  /*Check camera connectibity first */
  const char* command = "libcamera-hello --list-cameras";
  int result = system(command);
  if (result == 0) {
    std::cout << "Telecommand 306.1: Camera found \n";
    if (ttc->moduleDestID == 3061) {
      std::cout << "Telecommand 306.1: Destination ID match with this camera module \n";
      if (atom_thread_status == 0) {
        /* assign data to TTCInternal.value return */
        if (((imgNum >= 1) && (imgNum <= 5400)) && ((intervalTime >= 0) && (intervalTime <= 5100)) && ((integrationTime >= 5000) && (integrationTime <= 30000))) {
          std::cout << "Telecommand 306.1: All parameter set. This module will further take a picture \n";
          atom_thread_status = 1;
          //_ttc.ctrlType = CtrlType::TC_ret;
          std::cout << "TC 4 Accepted: " << std::flush;
          std::cout << _ttc.value << std::endl << std::flush;
          std::thread t1([=]() {
            try {
              // operation loop
              while (atom_thread_status == 1) {
                services->Log->log(LogLevel::INFO, "Telecommand 306.1: Processing.. \n");
                if ((imgNum == 1) && (intervalTime == 0) && ((integrationTime >= 5000) && (integrationTime <= 30000))) {
                  camCommand.CameraMode(camParam, services, imgNum, intervalTime, MODE_SINGLE);
                } else if (((imgNum > 1) && ((imgNum <= 5400))) && ((intervalTime >= 334) && (intervalTime <= 5100)) && ((integrationTime >= 5000) && (integrationTime <= 30000))) {
                  camCommand.CameraMode(camParam, services, imgNum, intervalTime, MODE_STRIP);
                } else if (((imgNum > 1) && ((imgNum <= 5400))) && (intervalTime == 0) && ((integrationTime >= 5000) && (integrationTime <= 30000))) {
                  camCommand.CameraMode(camParam, services, imgNum, intervalTime, MODE_VIDEO);
                } else {
                  std::cout << "Please check an acceptable values for the operation as follows: \n"
                               "- Image number: from 1 to 5400 \n"
                               "- Interval time: 334 to 5100 or 0 when capturing in single and video mode. \n"
                               "- Inegration time: from 5000 to 30000 \n";
                }
                /* Reset all global variable to zero and waiting for the next setup */
                imgNum = 0;
                intervalTime = 0;
                integrationTime = 0;
                frame_counter = 0;

                // sleep thread to prevent over perform
                // std::this_thread::sleep_for(std::chrono::milliseconds(1000));
                atom_thread_status = 0;
                services->Log->log(LogLevel::INFO, "Telecommand 306.1: End \n");
              }
            } catch (std::exception error) {
              if (error.what() == "Telecommand 306.1: Exception error \n") {
                services->Log->log(LogLevel::ERROR, "Telecommand 306.1: Exception error ");
              }
            }
            std::cout << "Telecommand 306.1: Thread closed \n";
          });
          t1.detach();
          _ttc.value = 0;
          std::cout << "Telecommand 306.1: Thread detached \n";
        } else {
          _ttc.value = 2;
          std::cout << "Please check an acceptable values for the operation as follows: \n"
                       "- Image number: from 1 to 5400 \n"
                       "- Interval time: 334 to 5100 or 0 when capturing in single and video mode. \n"
                       "- Inegration time: from 5000 to 30000 \n";
          /* Reset all global variable to zero and waiting for the next setup */
          imgNum = 0;
          intervalTime = 0;
          integrationTime = 0;
          frame_counter = 0;
        }
      } else {
        _ttc.value = 3;
        std::cout << "Telecommand 306.1: Camera is in operation. It will not accept an incoming command \n";
      }
    } else {
      _ttc.value = 1;
      std::cout << "Telecommand 306.1: Destination ID doesn't match with this camera module \n";
    }
  } else {
    _ttc.value = 4;
    std::cout << "Telecommand 306.1: Camera not found \n";
  }
  services->MQ_Return->Send(_ttc);
  return 0;
};

int CAM_TM_1(const TTCInternal* ttc, const Services* services) {
  TTCInternal _ttc = *ttc;
  _ttc.ctrlType = CtrlType::TM_ret;
  _ttc.value = atom_camera_status;
  services->MQ_Return->Send(_ttc);
  std::cout << "Camera status: " << atom_camera_status << std::endl << std::flush;
  return 0;
}

int CAM_TM_2(const TTCInternal* ttc, const Services* services) {
  TTCInternal _ttc = *ttc;
  _ttc.ctrlType = CtrlType::TM_ret;
  _ttc.value = atom_imaging_status;
  services->MQ_Return->Send(_ttc);

  std::cout << "Imaging status: " << atom_imaging_status << std::endl << std::flush;
  return 0;
}

int CAM_TM_3(const TTCInternal* ttc, const Services* services) {
  TTCInternal _ttc = *ttc;
  _ttc.ctrlType = CtrlType::TM_ret;
  _ttc.value = atom_writeback_status;
  services->MQ_Return->Send(_ttc);

  std::cout << "Writeback status: " << atom_writeback_status << std::endl << std::flush;
  return 0;
}

int CAM_TM_4(const TTCInternal* ttc, const Services* services) {
  TTCInternal _ttc = *ttc;
  _ttc.ctrlType = CtrlType::TM_ret;
  _ttc.value = imgNum;
  services->MQ_Return->Send(_ttc);

  std::cout << "Number of image to be captured: " << imgNum << std::endl << std::flush;
  return 0;
}

int CAM_TM_5(const TTCInternal* ttc, const Services* services) {
  TTCInternal _ttc = *ttc;
  _ttc.ctrlType = CtrlType::TM_ret;
  _ttc.value = intervalTime;
  services->MQ_Return->Send(_ttc);

  std::cout << "Interval time: " << intervalTime << std::endl << std::flush;
  return 0;
}

int CAM_TM_6(const TTCInternal* ttc, const Services* services) {
  TTCInternal _ttc = *ttc;
  _ttc.ctrlType = CtrlType::TM_ret;
  _ttc.value = integrationTime;
  services->MQ_Return->Send(_ttc);

  std::cout << "Integration time: " << integrationTime << std::endl << std::flush;
  return 0;
}

int CAM_TM_7(const TTCInternal* ttc, const Services* services) {
  services->Pool->Set(7, softwareVersion);
  TTCInternal _ttc = *ttc;
  _ttc.ctrlType = CtrlType::TM_ret;
  _ttc.value = softwareVersion;
  services->MQ_Return->Send(_ttc);

  std::cout << "Firmware version: " << softwareVersion << std::endl << std::flush;
  return 0;
}

std::string parameter;
std::string TeleCommand;

int main(int argc, char* argv[]) {
  auto fsw_pool = new Datapool("/303");
  auto logger = new Logger();
  logger->setLogLevel(fsw_pool->Get(5));
  logger->setModuleID(3061);
  logger->setLogMQName("/log.sub");
  logger->setManualMQService();

  Datapool* pool = new Datapool("/306.1");
  CMqueue* mq_request = new CMqueue("/306.1");
  CMqueue* mq_return = new CMqueue("/realtime");
  CMqueue* mq_log = new CMqueue("/log.sub");

  if (mq_return->OpenWrite() == -1) {
    logger->log(LogLevel::ERROR, "Failed to open message queue");
    return EXIT_FAILURE;
  } else {
    logger->log(LogLevel::INFO, "connected MQ_Return");
  }

  if (mq_request->OpenRead() == -1) {
    logger->log(LogLevel::ERROR, "Failed to open message queue");
    return EXIT_FAILURE;
  } else {
    logger->log(LogLevel::INFO, "connected MQ_Request");
  }

  if (mq_log->OpenWrite() == -1) {
    logger->log(LogLevel::ERROR, "Failed to open message queue");
    return EXIT_FAILURE;
  } else {
    logger->log(LogLevel::INFO, "connected MQ_Logger");
  }
  // ======================= Start subsystem code ========================================

  std::unordered_map<int, std::function<void(TTCInternal*, Services*)>> tc_actions;
  std::unordered_map<int, std::function<void(TTCInternal*, Services*)>> tm_actions;
  // tc_actions[<<commandID>>] = function()
  tc_actions[1] = CAM_TC_1;
  tc_actions[2] = CAM_TC_2;
  tc_actions[3] = CAM_TC_3;
  tc_actions[4] = CAM_TC_4;

  tm_actions[1] = CAM_TM_1;
  tm_actions[2] = CAM_TM_2;
  tm_actions[3] = CAM_TM_3;
  tm_actions[4] = CAM_TM_4;
  tm_actions[5] = CAM_TM_5;
  tm_actions[6] = CAM_TM_6;
  tm_actions[7] = CAM_TM_7;

  // ===============================================================
  TTCInternal message;
  unsigned int priority;
  Services* services = new Services;
  services->MQ_Return = mq_return;
  services->Log = logger;
  services->Pool = pool;

  while (true) {
    ssize_t bytes = mq_receive(mq_request->mq_dest, reinterpret_cast<char*>(&message), 64, NULL);
    if (bytes == -1) {
    } else {
      TTCInternal* msg = new TTCInternal;
      *msg = message;
      switch (message.ctrlType) {
        case CtrlType::TC_req:
          if (tc_actions.contains((int)message.commandID)) {
            tc_actions[message.commandID](msg, services);
          }
          break;
        case CtrlType::TM_req:
          if (tm_actions.contains((int)message.commandID)) {
            tm_actions[message.commandID](msg, services);
          }
          break;
      }
    }
  }
  return 0;
}
