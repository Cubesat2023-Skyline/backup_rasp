/*
████████╗██╗  ██╗███████╗ ██████╗ ███████╗      ██████╗  █████╗
╚══██╔══╝██║  ██║██╔════╝██╔═══██╗██╔════╝      ╚════██╗██╔══██╗
   ██║   ███████║█████╗  ██║   ██║███████╗█████╗ █████╔╝███████║
   ██║   ██╔══██║██╔══╝  ██║   ██║╚════██║╚════╝██╔═══╝ ██╔══██║
   ██║   ██║  ██║███████╗╚██████╔╝███████║      ███████╗██║  ██║
   ╚═╝   ╚═╝  ╚═╝╚══════╝ ╚═════╝ ╚══════╝      ╚══════╝╚═╝  ╚═╝

 File: ADHT22.cpp
 Author: [Jeerasak Ruamnapaya]
===============================================================
 [description here]

 Developer: [Jeerasak Ruamnapaya], Aroonsak Bootchai
 Project: SchoolSAT
 Date: 2023-Jun-30
 Version: 001
===============================================================
*/

/**
 * [x] application shall execute with minimum required arguments
 * [x] application shall able to load config file as mentioned from aguments
 * [x] the config file shall be shown registered TC and registered TM (which
 * validated from FSW)
 * [x] the TC and TM in unordered_map (which will able to
 * use find key)
 * [ ] every switch, boolean, shared data, shared value can be in
 * form of atomic & shared pointers
 * - Aroonsak Bootchai
 */

/** At main thread,
 * 1 ) [X] read and check arguments is correct from defined
 * 2 ) [X] read file from argument, the config shall be parsed from the file
then close file
 * 3 ) [X] read config,
 * [ ] if key have __TC__, parse the line by TC::parse then push TC to
unordered_map TCTable
 * [ ] if key have __TM__, parse the line by TM::parse then push TM to
unordered_map TMTable
 * [ ] else push the config to unordered_map Config
 * 4 ) [x] from config, parse the line by Config::parse then push Config to
unordered_map ConfigTable
 * 5 ) [x] TMFunction (unordered_map)
 * 6 ) [x] TCFunction (unordered_map)
 * 7 ) [x] detach a thread, Command Thread with (reference)TMTable,
(reference)TCTable, (reference)TMFUnction, (reference)TCFunction and Config as
arguments to thread
 * 8 ) [x] while loop to prevent the main thread stopped
 * - Aroonsak Bootchai
 */

/** 1 [ ] detached thread (Pthread) named Command thread, reading message from
 *message queue (using Config["mqueue"] as name ) and parse that to MsgPacket
 struct (message packet is a struct that  ...), after parsed,
 * [ ] if MsgPacket.ctrlType == 0 then find MsgPacket.commandID in TMFunction,
 exec TCFunc(MsgPacket)
 * [ ] if MsgPacket.ctrlType == 2 then find MsgPacket.commandID in TCFunction,
 exec TMFunc(MsgPacket)
 * - Aroonsak Bootchai
 **/

#include <fcntl.h>
#include <fmt/format.h>
#include <mqueue.h>
#include <sys/mman.h>
#include <unistd.h>

#include <atomic>
#include <chrono>
#include <fstream>
#include <functional>
#include <iostream>
#include <map>
#include <string>
#include <thread>
#include <vector>

#include "../include/CCommand.hpp"
#include "../include/CConfig.hpp"
#include "../include/CDataPool.hpp"
#include "../include/CExecutor.hpp"
#include "../include/CLog.hpp"
#include "../include/CMqueue.hpp"
#include "../include/ITTC.hpp"

// =============================== DHT22 Value ===============================
#include "../lib/rpi_dht22.h"

std::atomic<uint8_t> DHT_sampling_state = 0;
std::atomic<uint8_t> DHT_harness_check = 0;

#define START_ACCEPT 0
#define START_REJECT 1
#define STOP_ACCEPT 0
#define STOP_REJECT 1

#define CELSIUS_DEFAULT 32767
#define HUMIDITY_DEFAULT 65535
#define SOFTWARE_VERSION 101    // Version 1.00
#define DHT_SAMPLING_RATE 1000  // In millisecond

uint8_t DHT_status = 0;

rpi_dht22 dht22;

// ================================= TC Code =================================
int DHT_TC_1(const TTCInternal* ttc, const Services* services) {
  TTCInternal _ttc = *ttc;
  _ttc.ctrlType = CtrlType::TC_ret;

  // Check Status
  dht22.Init();
  if (dht22.WiringStatus() == -1) {
    DHT_harness_check = 0;
    DHT_status = 2;
  } else if (dht22.WiringStatus() != -1 && DHT_sampling_state == 1) {
    DHT_harness_check = 1;
    DHT_status = 1;
  } else if (dht22.WiringStatus() != -1 && DHT_sampling_state == 0) {
    DHT_harness_check = 1;
    DHT_status = 0;
  } else {
    DHT_status = 3;
  }

  // Harness cable Check: Connected and Thread check
  if (DHT_harness_check == 1 && DHT_sampling_state == 0) {
    DHT_sampling_state = 1;
    DHT_status = 1;

    _ttc.value = START_ACCEPT;
    services->MQ_Return->Send(_ttc);

    std::cout << "TC1 Accept: " << std::flush;
    std::cout << _ttc.value << std::endl << std::flush;

    std::thread t1([=]() {
      try {
        // int sensors data out
        int16_t celsius = CELSIUS_DEFAULT;
        uint16_t humidity = HUMIDITY_DEFAULT;

        // Float sensors data in
        float _celsius = CELSIUS_DEFAULT;
        float _humidity = HUMIDITY_DEFAULT;

        // Throw function
        bool cable_status;

        // loop data sampling
        while (DHT_sampling_state == 1) {
          if (dht22.WiringStatus() == -1) {
            throw cable_status;
          }
          dht22.Begin();
          _celsius = dht22.GetTemperature();
          _humidity = dht22.GetHumidity();

          celsius = _celsius;
          humidity = _humidity;

          // store data to datapool as [tmID] = [value]
          services->Pool->Set(2, celsius);
          services->Pool->Set(3, humidity);

          printf("Temp(C): %.1f | humidity: %.1f %% \t", _celsius / 10.0, _humidity / 10.0);
          printf("(RAW Data) Temp(C): %d | humidity: %d\n", celsius, humidity);

          // Delay minimum 200 ms
          std::this_thread::sleep_for(std::chrono::milliseconds(DHT_SAMPLING_RATE));
        }
      }

      // Catch Lost connect function
      catch (bool cable_status) {
        DHT_harness_check = 0;
        DHT_sampling_state = 0;
        services->Log->log(LogLevel::ERROR, "Lost Connection");
      }
      std::cout << "thread TC_1 closed" << std::endl << std::flush;
    });
    t1.detach();
  }

  // TC_1 Reject: Disconnected check TM_1 again
  else if (DHT_harness_check == 0 && DHT_sampling_state == 0) {
    _ttc.value = START_REJECT;
    services->MQ_Return->Send(_ttc);

    services->Log->log(LogLevel::WARNING, "TC_1 Reject: Disconnected");
  }

  // TC_1 Reject: Sampling
  else if (DHT_harness_check == 1 && DHT_sampling_state == 1) {
    _ttc.value = START_REJECT;
    services->MQ_Return->Send(_ttc);

    services->Log->log(LogLevel::WARNING, "TC_1 Reject: Sampling");
  }

  // TC_1 Reject: Unknow Error case
  else {
    DHT_status = 3;
    services->Log->log(LogLevel::ERROR, "TC_1 Reject: Unknow Error");
  }
  return 0;
}

int DHT_TC_2(const TTCInternal* ttc, const Services* services) {
  TTCInternal _ttc = *ttc;
  _ttc.ctrlType = CtrlType::TC_ret;

  if (DHT_sampling_state == 1) {
    _ttc.value = STOP_ACCEPT;
    DHT_sampling_state = 0;

    std::cout << "TC_2 Accept: " << std::flush;
  } else {
    _ttc.value = STOP_REJECT;

    std::cout << "TC_2 Reject: " << std::flush;
  }

  services->MQ_Return->Send(_ttc);
  std::cout << _ttc.value << std::endl << std::flush;
  return 0;
}

// ================================= TM Code =================================
int DHT_TM_1(const TTCInternal* ttc, const Services* services) {
  // Check Status
  dht22.Init();
  if (dht22.WiringStatus() == -1) {
    DHT_harness_check = 0;
    DHT_status = 2;
  } else if (dht22.WiringStatus() != -1 && DHT_sampling_state == 1) {
    DHT_harness_check = 1;
    DHT_status = 1;
  } else if (dht22.WiringStatus() != -1 && DHT_sampling_state == 0) {
    DHT_harness_check = 1;
    DHT_status = 0;
  } else {
    DHT_status = 3;
  }

  services->Pool->Set(1, DHT_status);

  // Log Status
  if (DHT_status == 2) {
    services->Log->log(LogLevel::WARNING, "Disconnected");
  } else if (DHT_status == 1) {
    services->Log->log(LogLevel::INFO, "Sampling");
  } else if (DHT_status == 0) {
    services->Log->log(LogLevel::INFO, "Stand by");
  } else {
    services->Log->log(LogLevel::ERROR, "Unknow Error");
  }

  TTCInternal _ttc = *ttc;
  _ttc.ctrlType = CtrlType::TM_ret;
  _ttc.value = DHT_status;
  services->MQ_Return->Send(_ttc);
  return 0;
}

int DHT_TM_2(const TTCInternal* ttc, const Services* services) {
  if (DHT_sampling_state == 0) {
    services->Pool->Set(2, CELSIUS_DEFAULT);
  }
  TTCInternal _ttc = *ttc;
  _ttc.ctrlType = CtrlType::TM_ret;
  _ttc.value = CELSIUS_DEFAULT;
  services->MQ_Return->Send(_ttc);

  std::cout << "Get Temp: " << std::flush;
  std::cout << CELSIUS_DEFAULT << std::endl << std::flush;
  return 0;
}

int DHT_TM_3(const TTCInternal* ttc, const Services* services) {
  if (DHT_sampling_state == 0) {
    services->Pool->Set(3, HUMIDITY_DEFAULT);
  }
  TTCInternal _ttc = *ttc;
  _ttc.ctrlType = CtrlType::TM_ret;
  _ttc.value = HUMIDITY_DEFAULT;
  services->MQ_Return->Send(_ttc);

  std::cout << "Get Humidity: " << std::flush;
  std::cout << HUMIDITY_DEFAULT << std::endl << std::flush;
  return 0;
}

int DHT_TM_4(const TTCInternal* ttc, const Services* services) {
  TTCInternal _ttc = *ttc;
  _ttc.ctrlType = CtrlType::TM_ret;
  _ttc.value = SOFTWARE_VERSION;
  services->MQ_Return->Send(_ttc);

  std::cout << "Software version: " << std::flush;
  std::cout << SOFTWARE_VERSION << std::endl << std::flush;
  return 0;
}

// ================================ Main code ================================
int main(int argc, char* argv[]) {
  auto fsw_pool = new Datapool("/303");
  auto logger = new Logger();
  logger->setLogLevel(fsw_pool->Get(5));
  logger->setModuleID(3062);

  Datapool* pool = new Datapool("/306.2");
  CMqueue* mq_request = new CMqueue("/306.2");
  CMqueue* mq_return = new CMqueue("/realtime");
  CMqueue* mq_log = new CMqueue("/log");

  if (mq_return->OpenWrite() == -1) {
    logger->log(LogLevel::ERROR, "Failed to open message queue");
    return EXIT_FAILURE;
  } else {
    logger->log(LogLevel::INFO, "connected MQ_Return");
  }

  if (mq_request->OpenRead() == -1) {
    logger->log(LogLevel::ERROR, "Failed to open message queue");
    return EXIT_FAILURE;
  } else {
    logger->log(LogLevel::INFO, "connected MQ_Request");
  }

  if (mq_log->OpenWrite() == -1) {
    logger->log(LogLevel::ERROR, "Failed to open message queue");
    return EXIT_FAILURE;
  } else {
    logger->log(LogLevel::INFO, "connected MQ_Logger");
  }

  // ========================== Start subsystem code ==========================
  std::unordered_map<int, std::function<void(TTCInternal*, Services*)>> tc_actions;
  std::unordered_map<int, std::function<void(TTCInternal*, Services*)>> tm_actions;

  // Initialize Setup wiringpi GPIO and Check status
  dht22.Init();

  // tc_actions[<<commandID>>] = function()
  tc_actions[1] = DHT_TC_1;
  tc_actions[2] = DHT_TC_2;

  // tm_actions[<<commandID>>] = function()
  tm_actions[1] = DHT_TM_1;
  tm_actions[2] = DHT_TM_2;
  tm_actions[3] = DHT_TM_3;
  tm_actions[4] = DHT_TM_4;

  // ============================== FSW Section ==============================
  CommandThreadParams* params = new CommandThreadParams;
  params->mq_return = mq_return;
  params->mq_request = mq_request;
  params->mq_logservice = mq_log;
  params->tc_actions = &tc_actions;
  params->tm_actions = &tm_actions;
  params->pool = pool;
  params->logger = logger;

  WaitDebug(params);
  // ============================ TM/TC Test code ============================
  // int input;
  // auto tc = new TTCInternal();
  // tc->ctrlType = CtrlType::TC_req;

  // auto tm = new TTCInternal();
  // tm->ctrlType = CtrlType::TM_req;

  // auto services = new Services();
  // services->Pool = pool;
  // services->MQ_Return = mq_return;
  // services->Log = logger;

  // while (true) {
  //   // Do other tasks if needed
  //   std::cin >> input;
  //   switch (input) {
  //     // ============================== TC Test
  //     ============================== case 1:  // TC [1] Start Sampling
  //       tc->commandID = 1;
  //       tc_actions[1](tc, services);
  //       break;
  //     case 2:  // TC [2] Stop Sampling
  //       tc->commandID = 2;
  //       tc_actions[2](tc, services);
  //       break;
  //       // ============================= TM Test
  //       =============================
  //     case 3:  // TM [1] Status
  //       tm->commandID = 1;
  //       tm_actions[1](tm, services);
  //       break;
  //     case 4:  // TM [2] Temperature
  //       tm->commandID = 2;
  //       tm_actions[2](tm, services);
  //       break;
  //     case 5:  // TM [3] Humidity
  //       tm->commandID = 3;
  //       tm_actions[3](tm, services);
  //       break;
  //     case 6:  // TM [4] Software Version
  //       tm->commandID = 4;
  //       tm_actions[4](tm, services);
  //       break;
  //   }
  // }
  // ==========================================================================
  // processQueue(tc_actions, tm_actions);

  // pthread_attr_destroy(&threadAttr);
  TTCInternal message;
  unsigned int priority;
  Services* services = new Services;
  services->MQ_Return = mq_return;
  services->Log = logger;
  services->Pool = pool;

  while (true) {
    ssize_t bytes = mq_receive(mq_request->mq_dest, reinterpret_cast<char*>(&message), 64, NULL);
    if (bytes == -1) {
    } else {
      TTCInternal* msg = new TTCInternal;
      *msg = message;
      switch (message.ctrlType) {
        case CtrlType::TC_req:
          if (tc_actions.contains((int)message.commandID)) {
            tc_actions[message.commandID](msg, services);
          }
          break;
        case CtrlType::TM_req:
          if (tm_actions.contains((int)message.commandID)) {
            tm_actions[message.commandID](msg, services);
          }
          break;
      }
    }
  }
  return 0;
}
