# This is auto run script. If not used please comment it.

cd /opt/schoolsat/TEMP/
./fsw_ProcessManager &

exit 0