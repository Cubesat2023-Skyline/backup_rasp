#include <iostream>
#include <unistd.h>
#include <math.h>
#include "src/ina219.h"

int main(int argc, char *argv[])
{
	float SHUNT_OHMS = 0.1;
	float MAX_EXPECTED_AMPS = 3.2;
        INA219 i(SHUNT_OHMS, MAX_EXPECTED_AMPS);
        i.configure(RANGE_16V, GAIN_8_320MV, ADC_12BIT, ADC_12BIT);
        std::cout << "time_s,bus_voltage_V" << std::endl;
        uint16_t time = 0;  
        while(true)
        {
        uint16_t voltage = i.voltage();
            std::cout << time << "s" <<  ","
                    <<(voltage)<< "V" 
                    		<< std::endl;
        uint16_t Check_voltage = i.Check_voltage();
              if (Check_voltage == 1) 
                std::cout << "ERROR Disconnected" << std::endl;
            time++;
                     usleep(1000000); //1s
        }

	return 0;
}
 