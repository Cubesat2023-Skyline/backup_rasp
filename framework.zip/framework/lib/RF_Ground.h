/*
████████╗██╗  ██╗███████╗ ██████╗ ███████╗      ██████╗  █████╗
╚══██╔══╝██║  ██║██╔════╝██╔═══██╗██╔════╝      ╚════██╗██╔══██╗
   ██║   ███████║█████╗  ██║   ██║███████╗█████╗ █████╔╝███████║
   ██║   ██╔══██║██╔══╝  ██║   ██║╚════██║╚════╝██╔═══╝ ██╔══██║
   ██║   ██║  ██║███████╗╚██████╔╝███████║      ███████╗██║  ██║
   ╚═╝   ╚═╝  ╚═╝╚══════╝ ╚═════╝ ╚══════╝      ╚══════╝╚═╝  ╚═╝

 File: RF.h
 Author: Tanatiti Promwongsa
===============================================================
 [description here]

 Developer: Tanatiti Promwongsa, Aroonsak Bootchai, Tidaporn Fuasungnoen
 Project: SchoolSAT
 Date: 2023-July-6
 Version: 010
===============================================================
*/
#include <pigpio.h>  //
#include <wiringPi.h>
#include <wiringPiSPI.h>

#include <bit>
#include <functional>
#include <iomanip>
#include <iostream>
#include <string>

#include "../include/ITTC.hpp"
#include "pigpiod_if2.h"

extern "C" {
#include "../lib/LoRa.h"
}

// clang-format off
// @formatter:off
#define spiCST      0
#define spiBUST     0
#define spiBUSR     (1<<8)
#define spiCSR      0
#define TxReset     25
#define TxDIO       7
#define RxReset     13
#define RxDIO       26
#define RxMode      1
#define TxMode      0
#define BW          BW125 //BW7_8 =0, BW10_4 = 1<<4, BW15_6 = 2<<4, BW20_8 = 3<<4, BW31_25 = 4<<4, BW41_7 = 5<<4, BW62_5 = 6<<4, BW125 = 7<<4, BW250 = 8<<4, BW500 = 9<<4
#define SF          SF7 //SF7 = 7<<4, SF8 = 8<<4, SF9 = 9<<4, SF10 = 10<<4,  SF11 = 11<<4,SF12 = 12<<4,
#define ECR         CR5 //CR5 = 1<<1, CR6 = 2<<1, R7 = 3<<1, CR8 = 4<<1
#define CRC_ON      1 //1 enable/ 0 disable
#define TxFrequency 449987500  //Hz449987500
#define RxFrequency 430012500  //Hz430012500
#define OUT_POWER   OP20 // OP 0 - 20 dBm
#define Gain        1
#define Current     240
#define Header      0 //0 = Explicit header mode/ 1 = Implicit header mode
#define preamble    6
#define syncW       0x34
// clang-format on
// @formatter:on

enum class RFMode : uint8_t
{
  Receiver,
  Transmitter,
};

class RFModule {
 private:
  char txbuf[255];  // bytes
  RFMode mode;

 public:
  LoRa_ctl modem;

  RFModule() {
    try {
      gpioInitialise();
    } catch (std::exception err) {
    }
  };

  int SetMode(RFMode mode) {
    mode = mode;
    switch (mode) {
      case RFMode::Receiver:
        // clang-format off
                    // @formatter:off
                    modem.RFmode             = RxMode; // RxMode = recieve; TxMode = transmitt
                    modem.spiCS              = spiCSR;//Raspberry SPI CE pin number
                    modem.spiBUS             = spiBUSR; //Raspberry SPI BUS pin number
                    modem.eth.preambleLen    = preamble;
                    modem.eth.bw             = BW;//Bandwidth 62.5KHz
                    modem.eth.sf             = SF;//Spreading Factor 12
                    modem.eth.ecr            = ECR;//Error coding rate CR4/8
                    modem.eth.freq           = RxFrequency;// 434.8MHz
                    modem.eth.resetGpioN     = RxReset;//GPIO13 on lora RESET pi
                    modem.eth.dio0GpioN      = RxDIO;//GPIO26 on lora DIO0 pin to control Rxdone and Txdone interrupts
                    modem.eth.outPower       = OUT_POWER;//Output power
                    modem.eth.powerOutPin    = PA_BOOST;//Power Amplifire pin
                    modem.eth.AGC            = Gain;//Auto Gain Control
                    modem.eth.OCP            = Current;// 45 to 240 mA. 0 to turn off protection
                    modem.eth.implicitHeader = Header;//Explicit header mode
                    modem.eth.syncWord       = syncW;

        // clang-format on
        // @formatter:on
        return 1;
        break;
      case RFMode::Transmitter:
        // clang-format off
                    // @formatter:off
                    modem.RFmode             = TxMode; // RxMode = recieve; TxMode = transmitt
                    modem.spiCS              = spiCST;//Raspberry SPI CE pin number
                    modem.spiBUS             = spiBUST;
                    modem.tx.data.buf        = txbuf;
                    modem.eth.preambleLen    = preamble;
                    modem.eth.bw             = BW;//Bandwidth 62.5KHz
                    modem.eth.sf             = SF;//Spreading Factor 12
                    modem.eth.ecr            = ECR;//Error coding rate CR4/8
                    modem.eth.CRC            = CRC_ON;//Turn on CRC checking
                    modem.eth.freq           = TxFrequency;// 434.8MHz
                    modem.eth.resetGpioN     = TxReset;//GPIO25 on lora RESET pin
                    modem.eth.dio0GpioN      = TxDIO;//GPIO7 on lora DIO0 pin to control Rxdone and Txdone interrupts
                    modem.eth.outPower       = OUT_POWER;//Output power
                    modem.eth.powerOutPin    = PA_BOOST;//Power Amplifire pin
                    modem.eth.AGC            = Gain;//Auto Gain Control
                    modem.eth.OCP            = Current;// 45 to 240 mA. 0 to turn off protection
                    modem.eth.implicitHeader = Header;//Explicit header mode
                    modem.eth.syncWord       = syncW;
        // clang-format on
        // @formatter:on
        return 2;
        break;
    }
    return 0;
  };

  int InitConnection() {
    LoRa_begin(&modem);
    return 0;
  }
  int isConnect() { return LoRa_check_conn(&modem); };

  int Receive() {
    LoRa_receive(&modem);
    return 0;
  };

  int Send(TTCBroadcast message) {
    LoRa_begin(&modem);
    memcpy(modem.tx.data.buf, (char *)&message, sizeof(TTCBroadcast));
    LoRa_send(&modem);
    return 0;
  };
  int SendString(std::straing message) {
    modem.tx.data.size = message.size();
    memcpy(modem.tx.data.buf, message.c_str(), message.size());
    printf("Hex: %s\n", message);
    LoRa_begin(&modem);
    // isConnect();//========================================================================
    LoRa_send(&modem);
    // printf("Tsym: %f\n", modem.tx.data.Tsym);
    // printf("Tpkt: %f\n", modem.tx.data.Tpkt);
    // printf("payloadSymbNb: %u\n", modem.tx.data.payloadSymbNb);
    // printf("Send Message = %s\n",modem.tx.data.buf);
    // printf("sleep %d seconds to transmitt complete\n", (int)modem.tx.data.Tpkt);
    return 0;
  };
  void SetReceiveFunction(std::function<void *(void *p)> receiveFunction) { modem.rx.callback = (UserRxDoneCallback)&receiveFunction; };
  void SetTransmitFunction(std::function<void *(txData *tx)> transmitFunction) { modem.tx.callback = (UserTxDoneCallback)&transmitFunction; };

  //  int CheckConnect(){
  //        std::cout << lora_reg_read_byte(modem.spid,REG) << std::endl
  //                 << lora_reg_read_byte(modem.spid,REG) << std::endl
  //                 << lora_reg_red_byte(modem.spid,REG) << std::endl
  //                 << lora_reg_read_byte(modem.spid,REG) << std::endl;
  //  }
  // int Send(TTCBroadcast message){
  //     // std::string text = "hello world";
  //     std::stringstream ss;
  //     ss << std::hex << std::setw(2) << std::setfill('0');

  //     unsigned char* bytes = reinterpret_cast<unsigned char*>(&message);
  //     for(size_t i = 0; i< sizeof(message); ++i){
  //         ss << static_cast<int>(bytes[i]);
  //     }

  //     // memcpy(modem.tx.data.buf,  (char*)&message, sizeof(TTCBroadcast));
  //     std::string hexString = ss.str();
  //     memcpy(modem.tx.data.buf, hexString.c_str(), sizeof(hexString));//copy data we'll sent to buffer
  //     LoRa_send(&modem);
  //     return 0;
  // };
};
