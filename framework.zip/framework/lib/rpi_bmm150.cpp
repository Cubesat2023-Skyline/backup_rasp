#include "./rpi_bmm150.h"

#include <wiringPi.h>
#include <wiringPiI2C.h>

#include <cmath>
#include <iostream>

#define BMM150_CHIPID 0x40

// Raw data
int16_t raw_x;
int16_t raw_y;
int16_t raw_z;

// Interpolate +/- 16 bits to +/- 1300 x,y and +/- 2500 z
float val_x;
float val_y;
float val_z;

// Sensor Range Value [Engineering value] [Int value] [Power]
float eng_num[4] = {-13000, 13000, -25000, 25000};
float int_num[2] = {-32768, 32767};
float pow_2 = 2.0;

BMM150_MagData mag_data;

rpi_bmm150::rpi_bmm150() { wiringPiSetup(); }

int rpi_bmm150::init(int id) {
  BMM150_Settings settings;
  settings.pwr_mode = BMM150_POWER_MODE_NORMAL;
  settings.data_rate = BMM150_DATA_RATE_10HZ;
  settings.xy_reps = BMM150_REG_REP_XY;
  settings.z_reps = BMM150_REG_REP_Z;

  fd = wiringPiI2CSetup(id);
  if (fd == -1) {
    return -1;
  }

  // Initialize BMM150 Set power mode to normal
  wiringPiI2CWriteReg8(fd, BMM150_REG_POWER_CONTROL, BMM150_POWER_MODE_NORMAL);
  wiringPiI2CWriteReg8(fd, BMM150_REG_DATA_RATE, settings.data_rate);
  wiringPiI2CWriteReg8(fd, BMM150_REG_REP_XY, settings.xy_reps);
  wiringPiI2CWriteReg8(fd, BMM150_REG_REP_Z, settings.z_reps);
  return 0;
}

int rpi_bmm150::i2c_check() {
  if (0x32 != wiringPiI2CReadReg8(fd, BMM150_CHIPID)) {
    return -1;
  }
  return 0;
}

int rpi_bmm150::readMagData() {
  // Raw Data
  raw_x = wiringPiI2CReadReg16(fd, BMM150_REG_DATA_X);
  raw_y = wiringPiI2CReadReg16(fd, BMM150_REG_DATA_Y);
  raw_z = wiringPiI2CReadReg16(fd, BMM150_REG_DATA_Z);

  // Interpolate
  val_x =
      (eng_num[0] + ((eng_num[1] - eng_num[0]) / (int_num[1] - int_num[0])) *
                        (raw_x - int_num[0]));
  val_y =
      (eng_num[0] + ((eng_num[1] - eng_num[0]) / (int_num[1] - int_num[0])) *
                        (raw_y - int_num[0]));
  val_z =
      (eng_num[2] + ((eng_num[3] - eng_num[2]) / (int_num[1] - int_num[0])) *
                        (raw_z - int_num[0]));

  // calibration equaltion: y = ax^2 + bx +c
  mag_data.x =
      (abc_1[0] * powf32(val_x, pow_2)) + (abc_1[1] * val_x) + abc_1[2];
  mag_data.y =
      (abc_2[0] * powf32(val_y, pow_2)) + (abc_2[1] * val_y) + abc_2[2];
  mag_data.z =
      (abc_3[0] * powf32(val_z, pow_2)) + (abc_3[1] * val_z) + abc_3[2];
  return 0;
}

int rpi_bmm150::get_magnetic_x() {
  mag_data.x;
  return mag_data.x;
}

int rpi_bmm150::get_magnetic_y() {
  mag_data.y;
  return mag_data.y;
}

int rpi_bmm150::get_magnetic_z() {
  mag_data.z;
  return mag_data.z;
}