#ifndef RPI_BMM150_H
#define RPI_BMM150_H

#include <stdint.h>

struct BMM150_Settings {
  uint8_t pwr_mode;
  uint8_t data_rate;
  uint8_t xy_reps;
  uint8_t z_reps;
};

struct BMM150_MagData {
  int16_t x;
  int16_t y;
  int16_t z;
};

// calibration parameter [ax^2 + bx + c]
// a -> Square; b -> Linear;  c -> Constant;

float abc_1[3] = {0, 1.0, 13.00};
float abc_2[3] = {0, 1.0, -10.00};
float abc_3[3] = {0, 1.0, 11.00};

class rpi_bmm150 {
 public:
  rpi_bmm150();

  int init(int id);      // initialize Setup GPIO and parameter for library
  int i2c_check();       // cable check: [0] = connected [-1] = Disconnected
  int readMagData();     // Sensor sampling processing
  int get_magnetic_x();  // Get data Magnetic x
  int get_magnetic_y();  // Get data Magnetic y
  int get_magnetic_z();  // Get data Magnetic z

  // Internal Process
 private:
  int16_t fd;
  const int8_t BMM150_REG_POWER_CONTROL = 0x4B;
  const int8_t BMM150_POWER_MODE_NORMAL = 0x01;

  const int8_t BMM150_REG_DATA_RATE = 0x4C;
  const int8_t BMM150_DATA_RATE_10HZ = 0x08;

  const int8_t BMM150_REG_REP_XY = 0x51;
  const int8_t BMM150_REG_REP_Z = 0x52;

  const int8_t BMM150_REG_DATA_X = 0x42;
  const int8_t BMM150_REG_DATA_Y = 0x44;
  const int8_t BMM150_REG_DATA_Z = 0x46;
};

#endif
