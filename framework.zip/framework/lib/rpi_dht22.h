#ifndef RPI_DHT22_h
#define RPI_DHT22_h

class rpi_dht22 {
 public:
  rpi_dht22();

  int Init();              // Initialize Setup GPIO 4 or Physical pin 7 on Rpi 4
  int Begin();             // Sensor sampling processing
  int WiringStatus();      // cable check: [0] = connected [-1] = Disconnected
  float GetTemperature();  // Get data Temperature [65535] = Default
  float GetHumidity();     // Get data Humidity [32767] = Default

 private:
  short ReceiveData();  // Internal Processing
};

#endif