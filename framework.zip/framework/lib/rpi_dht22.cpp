#include "./rpi_dht22.h"

#include <stdint.h>
#include <stdio.h>
#include <wiringPi.h>

#include <iostream>

// GPIO_signal 4
#define GPIO_SIGNAL 4
unsigned short data[5] = {0, 0, 0, 0, 0};

#define CELSIUS_DEFAULT 32767
#define HUMIDITY_DEFAULT 65535
#define RETURN_DEFAULT 32767

float celsius = CELSIUS_DEFAULT;
float humidity = HUMIDITY_DEFAULT;
short checksum = 0;

short wiringcheck = -1;

rpi_dht22::rpi_dht22() { wiringPiSetup(); }

// Setup GPIO 4 and wiringcheck
int rpi_dht22::Init() {
  wiringPiSetupGpio();
  Begin();
  delayMicroseconds(200000);
  WiringStatus();
  return 0;
}

// Cable Check: [0] = Connected [-1] = Disconnected
int rpi_dht22::WiringStatus() { return wiringcheck; }

int rpi_dht22::Begin() {
  pinMode(GPIO_SIGNAL, OUTPUT);
  digitalWrite(GPIO_SIGNAL, LOW);
  delayMicroseconds(1000);

  pinMode(GPIO_SIGNAL, INPUT);
  ReceiveData();

  checksum = (data[0] + data[1] + data[2] + data[3]) & 0xFF;

  if (data[4] == checksum && checksum != 0x00) {
    humidity = ((data[0] * 256) + data[1]);
    celsius = (((data[2] & 0x7F) * 256) + data[3]);

    if (data[2] == 0x80) {
      celsius *= -1;
    }
  }

  // Check wiring status
  if (checksum == 0) {
    wiringcheck = -1;
  } else {
    wiringcheck = 0;
  }

  for (unsigned char i = 0; i < 5; i++) {
    data[i] = 0;
  }
  return 0;
}

short rpi_dht22::ReceiveData() {
  unsigned short val = 0x00;
  unsigned short GPIO_signal_length = 0;
  unsigned short val_counter = 0;
  unsigned short loop_counter = 0;

  while (1) {
    while (digitalRead(GPIO_SIGNAL) == HIGH) {
      GPIO_signal_length++;

      if (GPIO_signal_length >= 200) {
        return -1;
      }
      delayMicroseconds(1);
    }

    if (GPIO_signal_length > 0) {
      loop_counter++;

      if (GPIO_signal_length < 10) {
        val <<= 1;
      }

      else if (GPIO_signal_length < 30) {
        val <<= 1;
      }

      else if (GPIO_signal_length < 85) {
        val <<= 1;
        val |= 1;
      }

      else {
        return -1;
      }

      GPIO_signal_length = 0;
      val_counter++;
    }

    if (loop_counter < 3) {
      val = 0x00;
      val_counter = 0;
    }

    if (val_counter >= 8) {
      data[(loop_counter / 8) - 1] = val;

      val = 0x00;
      val_counter = 0;
    }
  }
}

float rpi_dht22::GetTemperature() {
  if (celsius == 0) {
    return CELSIUS_DEFAULT;
  }
  celsius;
  return celsius;
}

float rpi_dht22::GetHumidity() {
  humidity;
  return humidity;
}